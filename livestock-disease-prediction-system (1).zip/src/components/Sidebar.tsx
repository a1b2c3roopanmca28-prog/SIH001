'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/context/auth-context';
import { 
  LayoutDashboard, 
  Stethoscope, 
  PlusCircle, 
  ClipboardList, 
  Settings, 
  LogOut,
  Activity,
  User,
  AlertTriangle,
  History
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function Sidebar() {
  const { user, logout } = useAuth();
  const pathname = usePathname();

  if (!user) return null;

  const farmerLinks = [
    { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
    { name: 'My Animals', href: '/dashboard/animals', icon: Activity },
    { name: 'Predict Disease', href: '/dashboard/predict', icon: Stethoscope },
    { name: 'Health Records', href: '/dashboard/records', icon: ClipboardList },
  ];

  const vetLinks = [
    { name: 'Dashboard', href: '/vet/dashboard', icon: LayoutDashboard },
  ];

  const adminLinks = [
    { name: 'Overview', href: '/admin', icon: LayoutDashboard },
  ];

  const links = user.role === 'farmer' ? farmerLinks : 
                user.role === 'veterinarian' ? vetLinks : adminLinks;

  return (
    <div className="flex flex-col w-64 bg-white border-r h-screen sticky top-0">
      <div className="flex items-center justify-center h-16 border-b px-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
            <Activity className="text-white w-5 h-5" />
          </div>
          <span className="text-xl font-bold text-gray-800">PashuRakshak</span>
        </div>
      </div>
      <div className="flex flex-col flex-1 overflow-y-auto">
        <nav className="flex-1 px-4 py-4 space-y-1">
          {links.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={cn(
                  'flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors',
                  pathname === item.href
                    ? 'bg-green-50 text-green-700'
                    : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
                )}
              >
                <Icon className="mr-3 h-5 w-5" />
                {item.name}
              </Link>
            );
          })}
        </nav>
        <div className="px-4 py-4 border-t">
          <div className="flex items-center gap-3 px-4 py-3 mb-2">
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
              <User className="w-5 h-5 text-gray-500" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{user.name}</p>
              <p className="text-xs text-gray-500 truncate capitalize">{user.role}</p>
            </div>
          </div>
          <button
            onClick={logout}
            className="flex items-center w-full px-4 py-3 text-sm font-medium text-red-600 rounded-lg hover:bg-red-50 transition-colors"
          >
            <LogOut className="mr-3 h-5 w-5" />
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}
