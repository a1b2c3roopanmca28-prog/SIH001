'use server';

import { db } from '@/db';
import { animals, cases, diseases } from '@/db/schema';
import { eq, desc } from 'drizzle-orm';
import { revalidatePath } from 'next/cache';

export async function getAnimals(ownerId: number) {
  return await db.select().from(animals).where(eq(animals.ownerId, ownerId));
}

export async function addAnimal(data: any) {
  const res = await db.insert(animals).values(data).returning();
  revalidatePath('/animals');
  return res[0];
}

export async function getRecentCases(farmerId: number) {
  return await db
    .select({
      id: cases.id,
      animalName: animals.name,
      diseaseName: diseases.name,
      confidence: cases.confidence,
      severity: cases.severity,
      status: cases.status,
      createdAt: cases.createdAt,
    })
    .from(cases)
    .innerJoin(animals, eq(cases.animalId, animals.id))
    .leftJoin(diseases, eq(cases.predictedDiseaseId, diseases.id))
    .where(eq(cases.farmerId, farmerId))
    .orderBy(desc(cases.createdAt))
    .limit(5);
}

export async function createCase(data: any) {
  const res = await db.insert(cases).values(data).returning();
  revalidatePath('/dashboard');
  revalidatePath('/records');
  return res[0];
}
