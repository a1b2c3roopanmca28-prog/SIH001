'use server';

import { db } from '@/db';
import { cases, animals, users, diseases } from '@/db/schema';
import { eq, desc, isNull } from 'drizzle-orm';
import { revalidatePath } from 'next/cache';

export async function getPendingCases() {
  return await db
    .select({
      id: cases.id,
      animalName: animals.name,
      animalType: animals.type,
      farmerName: users.name,
      farmerLocation: users.location,
      symptoms: cases.symptoms,
      predictedDisease: diseases.name,
      confidence: cases.confidence,
      severity: cases.severity,
      createdAt: cases.createdAt,
      status: cases.status,
    })
    .from(cases)
    .innerJoin(animals, eq(cases.animalId, animals.id))
    .innerJoin(users, eq(cases.farmerId, users.id))
    .leftJoin(diseases, eq(cases.predictedDiseaseId, diseases.id))
    .where(eq(cases.status, 'Pending'))
    .orderBy(desc(cases.createdAt));
}

export async function updateCaseStatus(caseId: number, vetId: number, status: 'Diagnosed' | 'Resolved', notes: string) {
  await db
    .update(cases)
    .set({
      vetId,
      status,
      notes,
    })
    .where(eq(cases.id, caseId));
  
  revalidatePath('/vet/dashboard');
  revalidatePath('/vet/cases');
}
