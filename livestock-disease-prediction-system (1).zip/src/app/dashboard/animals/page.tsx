'use client';

import React, { useEffect, useState } from 'react';
import DashboardLayout from '../layout';
import { useAuth } from '@/context/auth-context';
import { getAnimals, addAnimal } from '@/app/actions/farmer';
import { 
  Plus, 
  Activity, 
  Tag, 
  Scale, 
  Calendar,
  Search,
  X
} from 'lucide-react';

export default function AnimalsPage() {
  const { user } = useAuth();
  const [animals, setAnimals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    type: 'Cow',
    breed: '',
    age: '',
    gender: 'Female',
    weight: '',
  });

  useEffect(() => {
    async function loadData() {
      if (user) {
        const data = await getAnimals(user.id);
        setAnimals(data);
        setLoading(false);
      }
    }
    loadData();
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const newAnimal = await addAnimal({
      ...formData,
      ownerId: user.id,
      age: parseInt(formData.age),
      weight: parseFloat(formData.weight),
    });

    setAnimals([...animals, newAnimal]);
    setIsAdding(false);
    setFormData({ name: '', type: 'Cow', breed: '', age: '', gender: 'Female', weight: '' });
  };

  if (loading) return (
    <DashboardLayout>
      <div className="flex h-64 items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    </DashboardLayout>
  );

  return (
    <DashboardLayout>
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Animals</h1>
          <p className="text-gray-600">Manage and track your livestock collection.</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-green-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-green-700 flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Add Animal
        </button>
      </div>

      <div className="mb-6 relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input 
          type="text" 
          placeholder="Search by name or breed..." 
          className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-500 outline-none"
        />
      </div>

      {animals.length === 0 ? (
        <div className="bg-white rounded-xl p-12 text-center border-2 border-dashed">
          <Activity className="w-16 h-16 text-gray-200 mx-auto mb-4" />
          <h3 className="text-lg font-bold text-gray-900">No animals registered</h3>
          <p className="text-gray-500 mb-6">Start by adding your first animal to track its health.</p>
          <button 
            onClick={() => setIsAdding(true)}
            className="text-green-600 font-bold hover:underline"
          >
            Add an animal now
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {animals.map((animal) => (
            <div key={animal.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-4">
                <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                  <span className="text-2xl">🐄</span>
                </div>
                <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded-full uppercase tracking-wider">
                  {animal.type}
                </span>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-1">{animal.name}</h3>
              <p className="text-sm text-gray-500 mb-4">{animal.breed}</p>
              
              <div className="grid grid-cols-2 gap-4 text-sm border-t pt-4">
                <div className="flex items-center gap-2 text-gray-600">
                  <Calendar className="w-4 h-4" />
                  {animal.age} Years
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Scale className="w-4 h-4" />
                  {animal.weight} kg
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <Tag className="w-4 h-4" />
                  {animal.gender}
                </div>
                <div className="flex items-center gap-2 text-green-600 font-medium">
                  <Activity className="w-4 h-4" />
                  Healthy
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Animal Modal */}
      {isAdding && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden">
            <div className="p-6 border-b flex justify-between items-center">
              <h2 className="text-xl font-bold">Add New Animal</h2>
              <button onClick={() => setIsAdding(false)}><X className="w-6 h-6" /></button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <input 
                  required
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full p-2 border rounded-lg" 
                  placeholder="e.g. Gauri" 
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Type</label>
                  <select 
                    value={formData.type}
                    onChange={e => setFormData({...formData, type: e.target.value})}
                    className="w-full p-2 border rounded-lg"
                  >
                    <option>Cow</option>
                    <option>Buffalo</option>
                    <option>Goat</option>
                    <option>Sheep</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Breed</label>
                  <input 
                    value={formData.breed}
                    onChange={e => setFormData({...formData, breed: e.target.value})}
                    className="w-full p-2 border rounded-lg" 
                    placeholder="e.g. Gir" 
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Age</label>
                  <input 
                    type="number"
                    value={formData.age}
                    onChange={e => setFormData({...formData, age: e.target.value})}
                    className="w-full p-2 border rounded-lg" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Weight</label>
                  <input 
                    type="number"
                    value={formData.weight}
                    onChange={e => setFormData({...formData, weight: e.target.value})}
                    className="w-full p-2 border rounded-lg" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Gender</label>
                  <select 
                    value={formData.gender}
                    onChange={e => setFormData({...formData, gender: e.target.value})}
                    className="w-full p-2 border rounded-lg"
                  >
                    <option>Female</option>
                    <option>Male</option>
                  </select>
                </div>
              </div>
              <button 
                type="submit"
                className="w-full bg-green-600 text-white py-3 rounded-lg font-bold mt-4 hover:bg-green-700"
              >
                Register Animal
              </button>
            </form>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
