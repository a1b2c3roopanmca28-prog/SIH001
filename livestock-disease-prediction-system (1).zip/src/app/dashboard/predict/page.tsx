'use client';

import React, { useState, useEffect } from 'react';
import DashboardLayout from '../layout';
import { useAuth } from '@/context/auth-context';
import { getAnimals, createCase } from '@/app/actions/farmer';
import { predictDisease, PredictionResult } from '@/lib/prediction-engine';
import { 
  Stethoscope, 
  CheckCircle2, 
  AlertCircle,
  ChevronLeft,
  Loader2
} from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

const SYMPTOMS = [
  'Fever', 'Cough', 'Nasal discharge', 'Diarrhea', 'Loss of appetite', 
  'Reduced milk production', 'Swelling', 'Skin nodules', 'Lameness', 
  'Excessive salivation', 'Breathing difficulty', 'Eye discharge', 
  'Wounds or lesions', 'Blisters in mouth', 'Swollen udder', 'Clotted milk',
  'Pain', 'Heat in udder', 'Muscle tremors', 'Inability to stand',
  'Cold ears', 'Low body temperature', 'Abortion', 'Retention of placenta'
];

export default function PredictPage() {
  const { user } = useAuth();
  const router = useRouter();
  const [animals, setAnimals] = useState<any[]>([]);
  const [selectedAnimal, setSelectedAnimal] = useState('');
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [results, setResults] = useState<PredictionResult[] | null>(null);
  const [isPredicting, setIsPredicting] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadAnimals() {
      if (user) {
        const data = await getAnimals(user.id);
        setAnimals(data);
        setLoading(false);
      }
    }
    loadAnimals();
  }, [user]);

  const toggleSymptom = (symptom: string) => {
    setSelectedSymptoms(prev => 
      prev.includes(symptom) 
        ? prev.filter(s => s !== symptom)
        : [...prev, symptom]
    );
  };

  const handlePredict = async () => {
    if (!selectedAnimal || selectedSymptoms.length === 0) return;
    
    setIsPredicting(true);
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const predictions = predictDisease(selectedSymptoms);
    setResults(predictions);
    setIsPredicting(false);

    // Save case to DB
    if (predictions.length > 0) {
      const topResult = predictions[0];
      await createCase({
        animalId: parseInt(selectedAnimal),
        farmerId: user!.id,
        symptoms: selectedSymptoms,
        predictedDiseaseId: topResult.id,
        confidence: topResult.confidence / 100,
        severity: topResult.severity,
        status: 'Pending',
      });
    }
  };

  if (loading) return (
    <DashboardLayout>
      <div className="flex h-64 items-center justify-center">
        <Loader2 className="animate-spin h-8 w-8 text-green-600" />
      </div>
    </DashboardLayout>
  );

  return (
    <DashboardLayout>
      <div className="mb-6 flex items-center gap-4">
        <Link href="/dashboard" className="p-2 hover:bg-gray-100 rounded-full transition-colors">
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </Link>
        <h1 className="text-2xl font-bold text-gray-900">Disease Prediction</h1>
      </div>

      {!results ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 max-w-3xl mx-auto">
          <div className="mb-8">
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Animal</label>
            <select
              value={selectedAnimal}
              onChange={(e) => setSelectedAnimal(e.target.value)}
              className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 outline-none"
            >
              <option value="">Select an animal...</option>
              {animals.map(a => (
                <option key={a.id} value={a.id}>{a.name} ({a.type})</option>
              ))}
            </select>
          </div>

          <div className="mb-8">
            <label className="block text-sm font-medium text-gray-700 mb-4">Select Observed Symptoms</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {SYMPTOMS.map(s => (
                <button
                  key={s}
                  onClick={() => toggleSymptom(s)}
                  className={`p-3 text-sm text-left rounded-lg border transition-all ${
                    selectedSymptoms.includes(s)
                      ? 'bg-green-50 border-green-200 text-green-700'
                      : 'bg-white border-gray-200 text-gray-600 hover:border-green-200'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handlePredict}
            disabled={!selectedAnimal || selectedSymptoms.length === 0 || isPredicting}
            className="w-full bg-green-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-colors"
          >
            {isPredicting ? (
              <>
                <Loader2 className="w-6 h-6 animate-spin" />
                Analyzing Symptoms...
              </>
            ) : (
              <>
                <Stethoscope className="w-6 h-6" />
                Run AI Prediction
              </>
            )}
          </button>
        </div>
      ) : (
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-bold text-gray-900">Prediction Results</h2>
              <button 
                onClick={() => setResults(null)}
                className="text-green-600 font-medium hover:underline"
              >
                Start Over
              </button>
            </div>

            {results.length === 0 ? (
              <div className="text-center py-12">
                <AlertCircle className="w-16 h-16 text-orange-400 mx-auto mb-4" />
                <h3 className="text-lg font-bold text-gray-900">No match found</h3>
                <p className="text-gray-600">We couldn't identify a specific disease based on the selected symptoms. Please consult a veterinarian.</p>
              </div>
            ) : (
              <div className="space-y-8">
                {results.map((r, index) => (
                  <div key={index} className={`p-6 rounded-xl border-2 ${index === 0 ? 'border-green-500 bg-green-50' : 'border-gray-100'}`}>
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-xl font-bold text-gray-900">{r.disease}</h3>
                          {index === 0 && <span className="bg-green-600 text-white text-xs px-2 py-0.5 rounded-full">Most Likely</span>}
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <span className="text-gray-600 font-medium">Confidence: <span className="text-green-700">{r.confidence}%</span></span>
                          <span className={`font-medium ${r.severity === 'High' ? 'text-red-600' : 'text-orange-600'}`}>
                            Severity: {r.severity}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <p className="text-sm font-bold text-gray-700 mb-2">Matched Symptoms:</p>
                      <div className="flex flex-wrap gap-2">
                        {r.matchedSymptoms.map(s => (
                          <span key={s} className="bg-white px-2.5 py-1 rounded-md border text-xs text-gray-600 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-green-500" />
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="bg-white p-4 rounded-lg border border-gray-200">
                      <p className="text-sm font-bold text-gray-700 mb-1 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-orange-500" />
                        Recommended Action:
                      </p>
                      <p className="text-sm text-gray-600">{r.recommendations}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            <div className="mt-8 flex justify-center">
              <Link 
                href="/dashboard"
                className="bg-gray-900 text-white px-8 py-3 rounded-lg font-bold hover:bg-gray-800 transition-colors"
              >
                Back to Dashboard
              </Link>
            </div>
          </div>
        </div>
      )}
    </DashboardLayout>
  );
}
