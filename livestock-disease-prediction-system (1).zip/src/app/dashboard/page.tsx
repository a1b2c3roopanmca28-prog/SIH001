'use client';

import React, { useEffect, useState } from 'react';
import DashboardLayout from './layout';
import { useAuth } from '@/context/auth-context';
import { getAnimals, getRecentCases } from '@/app/actions/farmer';
import { 
  Activity, 
  PlusCircle, 
  AlertTriangle, 
  ChevronRight,
  Clipboard,
  Stethoscope
} from 'lucide-react';
import Link from 'next/link';
import { format } from 'date-fns';

export default function FarmerDashboard() {
  const { user } = useAuth();
  const [animalsCount, setAnimalsCount] = useState(0);
  const [recentCases, setRecentCases] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      if (user) {
        const animals = await getAnimals(user.id);
        const cases = await getRecentCases(user.id);
        setAnimalsCount(animals.length);
        setRecentCases(cases);
        setLoading(false);
      }
    }
    loadData();
  }, [user]);

  if (loading) return (
    <DashboardLayout>
      <div className="flex h-64 items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
      </div>
    </DashboardLayout>
  );

  return (
    <DashboardLayout>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Welcome back, {user?.name}!</h1>
        <p className="text-gray-600">Here is what is happening with your livestock today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Activity className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded-full">Total</span>
          </div>
          <h3 className="text-gray-500 text-sm font-medium">My Animals</h3>
          <p className="text-2xl font-bold text-gray-900">{animalsCount}</p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-orange-50 rounded-lg">
              <AlertTriangle className="w-6 h-6 text-orange-600" />
            </div>
            <span className="text-xs font-medium text-orange-600 bg-orange-50 px-2 py-1 rounded-full">Active</span>
          </div>
          <h3 className="text-gray-500 text-sm font-medium">Pending Cases</h3>
          <p className="text-2xl font-bold text-gray-900">
            {recentCases.filter(c => c.status === 'Pending').length}
          </p>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="p-2 bg-green-50 rounded-lg">
              <Clipboard className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-xs font-medium text-green-600 bg-green-50 px-2 py-1 rounded-full">Soon</span>
          </div>
          <h3 className="text-gray-500 text-sm font-medium">Upcoming Vaccinations</h3>
          <p className="text-2xl font-bold text-gray-900">2</p>
        </div>
      </div>

      {/* Mid Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
            <Clipboard className="w-5 h-5 text-green-600" />
            Vaccination Reminders
          </h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-orange-50 border border-orange-100 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center font-bold text-orange-600">F</div>
                <div>
                  <p className="font-bold text-gray-900 text-sm">FMD Booster</p>
                  <p className="text-xs text-gray-500">Animal: Gauri (Cow)</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-orange-600">In 3 days</p>
              </div>
            </div>
            <div className="flex items-center justify-between p-4 bg-blue-50 border border-blue-100 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center font-bold text-blue-600">B</div>
                <div>
                  <p className="font-bold text-gray-900 text-sm">Brucellosis Test</p>
                  <p className="text-xs text-gray-500">Animal: Shera (Buffalo)</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-blue-600">In 7 days</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            Regional Health Alerts
          </h2>
          <div className="space-y-4">
            <div className="p-4 bg-red-50 border border-red-100 rounded-lg">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-bold text-red-900 text-sm">High Risk: Lumpy Skin Disease</p>
                  <p className="text-xs text-red-700 mt-1">Increase in cases within 20km. Monitor for skin nodules.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Cases */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b border-gray-100 flex items-center justify-between">
            <h2 className="text-lg font-bold text-gray-900">Recent Health Checks</h2>
            <Link href="/dashboard/records" className="text-sm font-medium text-green-600 hover:text-green-700">View All</Link>
          </div>
          <div className="divide-y divide-gray-100">
            {recentCases.length === 0 ? (
              <div className="p-8 text-center text-gray-500">No health checks yet.</div>
            ) : (
              recentCases.map((c) => (
                <div key={c.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-gray-900">{c.animalName}</p>
                      <p className="text-sm text-gray-500">
                        {c.diseaseName || 'Unknown Disease'} • {format(new Date(c.createdAt), 'MMM dd, yyyy')}
                      </p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        c.severity === 'High' ? 'bg-red-100 text-red-700' : 
                        c.severity === 'Medium' ? 'bg-orange-100 text-orange-700' : 
                        'bg-blue-100 text-blue-700'
                      }`}>
                        {c.severity}
                      </span>
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="space-y-6">
          <div className="bg-green-600 rounded-xl p-6 text-white shadow-lg shadow-green-200">
            <h2 className="text-xl font-bold mb-2">Need a checkup?</h2>
            <p className="text-green-50 mb-6">Predict diseases instantly using our AI tool.</p>
            <Link 
              href="/dashboard/predict" 
              className="inline-flex items-center gap-2 bg-white text-green-600 px-6 py-3 rounded-lg font-semibold hover:bg-green-50 transition-colors"
            >
              <Stethoscope className="w-5 h-5" />
              Start AI Prediction
            </Link>
          </div>
          <div className="bg-white rounded-xl p-6 border border-gray-100 shadow-sm">
            <h2 className="text-lg font-bold text-gray-900 mb-4">Add New Animal</h2>
            <p className="text-gray-600 mb-6">Register a new animal in your farm.</p>
            <Link 
              href="/dashboard/animals" 
              className="inline-flex items-center gap-2 text-green-600 font-semibold hover:text-green-700"
            >
              <PlusCircle className="w-5 h-5" />
              Register Animal
            </Link>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
