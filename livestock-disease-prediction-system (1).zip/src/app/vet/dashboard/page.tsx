'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/context/auth-context';
import { Sidebar } from '@/components/Sidebar';
import { getPendingCases, updateCaseStatus } from '@/app/actions/vet';
import { 
  AlertTriangle, 
  MapPin, 
  Calendar, 
  MessageSquare,
  CheckCircle,
  XCircle,
  ChevronRight
} from 'lucide-react';
import { format } from 'date-fns';

export default function VetDashboard() {
  const { user } = useAuth();
  const [cases, setCases] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCase, setSelectedCase] = useState<any>(null);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    async function loadCases() {
      const data = await getPendingCases();
      setCases(data);
      setLoading(false);
    }
    loadCases();
  }, []);

  const handleUpdate = async (status: 'Diagnosed' | 'Resolved') => {
    if (!selectedCase || !user) return;
    await updateCaseStatus(selectedCase.id, user.id, status, notes);
    setCases(prev => prev.filter(c => c.id !== selectedCase.id));
    setSelectedCase(null);
    setNotes('');
  };

  if (loading) return (
    <div className="flex h-screen items-center justify-center bg-gray-50">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600"></div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-y-auto bg-gray-50 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Veterinarian Dashboard</h1>
            <p className="text-gray-600">Manage reported cases and monitor regional health trends.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                  <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-orange-500" />
                    Pending Cases ({cases.length})
                  </h2>
                </div>
                <div className="divide-y divide-gray-100">
                  {cases.length === 0 ? (
                    <div className="p-12 text-center">
                      <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
                      <p className="text-gray-500 font-medium">No pending cases! All clear.</p>
                    </div>
                  ) : (
                    cases.map((c) => (
                      <div 
                        key={c.id} 
                        onClick={() => setSelectedCase(c)}
                        className={`p-6 hover:bg-gray-50 cursor-pointer transition-colors ${selectedCase?.id === c.id ? 'bg-green-50' : ''}`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <p className="font-bold text-gray-900">{c.animalName} ({c.animalType})</p>
                              <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                                c.severity === 'High' ? 'bg-red-100 text-red-700' : 
                                c.severity === 'Medium' ? 'bg-orange-100 text-orange-700' : 
                                'bg-blue-100 text-blue-700'
                              }`}>
                                {c.severity}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600 font-medium">Owner: {c.farmerName}</p>
                            <div className="flex items-center gap-4 text-xs text-gray-500 mt-2">
                              <span className="flex items-center gap-1">
                                <MapPin className="w-3 h-3" />
                                {c.farmerLocation}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="w-3 h-3" />
                                {format(new Date(c.createdAt), 'MMM dd, HH:mm')}
                              </span>
                            </div>
                          </div>
                          <ChevronRight className="w-5 h-5 text-gray-400" />
                        </div>
                        <div className="mt-4 flex flex-wrap gap-2">
                          {c.symptoms.map((s: string) => (
                            <span key={s} className="bg-white px-2 py-0.5 rounded border text-xs text-gray-500">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            <div className="lg:col-span-1">
              {selectedCase ? (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 sticky top-8">
                  <h2 className="text-lg font-bold text-gray-900 mb-6">Case Details</h2>
                  
                  <div className="space-y-6">
                    <div>
                      <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">AI Prediction</label>
                      <div className="mt-1 p-3 bg-blue-50 rounded-lg border border-blue-100">
                        <p className="font-bold text-blue-900">{selectedCase.predictedDisease}</p>
                        <p className="text-sm text-blue-700">{Math.round(selectedCase.confidence * 100)}% Confidence</p>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-gray-500 uppercase tracking-wider">Clinical Notes</label>
                      <textarea
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Add your observation and advice..."
                        className="mt-1 w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-green-500 outline-none h-32"
                      ></textarea>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <button
                        onClick={() => handleUpdate('Diagnosed')}
                        className="flex items-center justify-center gap-2 bg-green-600 text-white py-3 rounded-lg font-bold hover:bg-green-700 transition-colors"
                      >
                        <CheckCircle className="w-5 h-5" />
                        Diagnose
                      </button>
                      <button
                        onClick={() => setSelectedCase(null)}
                        className="flex items-center justify-center gap-2 bg-gray-100 text-gray-700 py-3 rounded-lg font-bold hover:bg-gray-200 transition-colors"
                      >
                        <XCircle className="w-5 h-5" />
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 text-center border-dashed border-2">
                  <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Select a case from the list to view details and provide diagnosis.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
