'use client';

import React from 'react';
import { useAuth } from '@/context/auth-context';
import { useRouter } from 'next/navigation';
import { Activity, ShieldCheck, Stethoscope, Users } from 'lucide-react';

export default function Home() {
  const { login, user } = useAuth();
  const router = useRouter();

  if (user) {
    if (user.role === 'farmer') router.push('/dashboard');
    else if (user.role === 'veterinarian') router.push('/vet/dashboard');
    else if (user.role === 'admin') router.push('/admin');
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden bg-green-50 py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl">
              PashuRakshak AI
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-600">
              AI-powered livestock disease prediction and management platform. 
              Empowering farmers with early detection and professional veterinary support.
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <button
                onClick={() => login('farmer')}
                className="rounded-md bg-green-600 px-6 py-3 text-lg font-semibold text-white shadow-sm hover:bg-green-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-green-600"
              >
                Farmer Login
              </button>
              <button
                onClick={() => login('veterinarian')}
                className="text-lg font-semibold leading-6 text-gray-900 border border-gray-300 px-6 py-3 rounded-md hover:bg-gray-50 transition-colors"
              >
                Veterinarian Login
              </button>
              <button
                onClick={() => login('admin')}
                className="text-sm font-medium text-gray-500 hover:text-gray-700"
              >
                Admin Access
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto max-w-2xl lg:text-center">
            <h2 className="text-base font-semibold leading-7 text-green-600">Smart Livestock Care</h2>
            <p className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
              Everything you need to keep your livestock healthy
            </p>
          </div>
          <div className="mx-auto mt-16 max-w-2xl sm:mt-20 lg:mt-24 lg:max-w-none">
            <dl className="grid max-w-xl grid-cols-1 gap-x-8 gap-y-16 lg:max-w-none lg:grid-cols-3">
              <div className="flex flex-col">
                <dt className="flex items-center gap-x-3 text-base font-semibold leading-7 text-gray-900">
                  <Stethoscope className="h-5 w-5 flex-none text-green-600" />
                  AI Disease Prediction
                </dt>
                <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-gray-600">
                  <p className="flex-auto">Instantly predict diseases based on symptoms with high accuracy using our trained ML models.</p>
                </dd>
              </div>
              <div className="flex flex-col">
                <dt className="flex items-center gap-x-3 text-base font-semibold leading-7 text-gray-900">
                  <Activity className="h-5 w-5 flex-none text-green-600" />
                  Health Monitoring
                </dt>
                <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-gray-600">
                  <p className="flex-auto">Track animal history, vaccination records, and growth metrics in one place.</p>
                </dd>
              </div>
              <div className="flex flex-col">
                <dt className="flex items-center gap-x-3 text-base font-semibold leading-7 text-gray-900">
                  <ShieldCheck className="h-5 w-5 flex-none text-green-600" />
                  Outbreak Alerts
                </dt>
                <dd className="mt-4 flex flex-auto flex-col text-base leading-7 text-gray-600">
                  <p className="flex-auto">Get real-time alerts about disease outbreaks in your region to take preventive measures.</p>
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </div>
    </div>
  );
}
