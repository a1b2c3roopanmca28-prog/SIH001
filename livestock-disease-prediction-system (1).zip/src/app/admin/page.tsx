'use client';

import React, { useEffect, useState } from 'react';
import { useAuth } from '@/context/auth-context';
import { Sidebar } from '@/components/Sidebar';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  AlertOctagon,
  Map as MapIcon,
  Search
} from 'lucide-react';

export default function AdminDashboard() {
  const { user } = useAuth();

  const stats = [
    { label: 'Total Farmers', value: '1,284', icon: Users, color: 'blue' },
    { label: 'Active Outbreaks', value: '3', icon: AlertOctagon, color: 'red' },
    { label: 'Total Predictions', value: '5,621', icon: BarChart3, color: 'green' },
    { label: 'Vaccination Rate', value: '82%', icon: TrendingUp, color: 'purple' },
  ];

  const outbreaks = [
    { id: 1, disease: 'Lumpy Skin Disease', region: 'Punjab', cases: 45, status: 'Active' },
    { id: 2, disease: 'Foot and Mouth Disease', region: 'Haryana', cases: 12, status: 'Active' },
    { id: 3, disease: 'Mastitis', region: 'Uttar Pradesh', cases: 89, status: 'Monitoring' },
  ];

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar />
      <main className="flex-1 overflow-y-auto bg-gray-50 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8 flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Government Administration</h1>
              <p className="text-gray-600">Regional health surveillance and outbreak management.</p>
            </div>
            <div className="flex gap-3">
              <button className="bg-white border border-gray-200 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50 flex items-center gap-2">
                <Search className="w-4 h-4" />
                Filter Data
              </button>
              <button className="bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700">
                Generate Report
              </button>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, i) => {
              const Icon = stat.icon;
              return (
                <div key={i} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${
                    stat.color === 'blue' ? 'bg-blue-50 text-blue-600' :
                    stat.color === 'red' ? 'bg-red-50 text-red-600' :
                    stat.color === 'green' ? 'bg-green-50 text-green-600' :
                    'bg-purple-50 text-purple-600'
                  }`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-gray-500 text-sm font-medium">{stat.label}</h3>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Heatmap Placeholder */}
            <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                  <MapIcon className="w-5 h-5 text-blue-500" />
                  Disease Distribution Heatmap
                </h2>
                <div className="flex gap-2">
                  <span className="w-3 h-3 bg-red-500 rounded-full"></span>
                  <span className="text-xs text-gray-500">High Risk</span>
                </div>
              </div>
              <div className="h-96 bg-gray-100 relative overflow-hidden flex items-center justify-center">
                 {/* Simulated Map Background */}
                 <div className="absolute inset-0 opacity-20">
                    <svg className="w-full h-full" viewBox="0 0 800 500">
                      <path d="M100,100 L200,50 L300,150 L250,300 L100,250 Z" fill="currentColor" className="text-gray-400" />
                      <path d="M400,200 L550,150 L600,300 L450,400 Z" fill="currentColor" className="text-gray-400" />
                    </svg>
                 </div>
                 {/* Hotspots */}
                 <div className="relative">
                    <div className="absolute top-1/4 left-1/4 w-24 h-24 bg-red-500 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse"></div>
                    <div className="absolute top-1/2 left-1/3 w-16 h-16 bg-red-400 rounded-full mix-blend-multiply filter blur-xl opacity-40"></div>
                    <div className="absolute top-1/3 right-1/4 w-32 h-32 bg-orange-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
                    
                    <div className="z-10 bg-white/80 backdrop-blur px-4 py-2 rounded-lg shadow-lg border border-white">
                      <p className="text-xs font-bold text-gray-900 uppercase">Punjab Cluster</p>
                      <p className="text-sm text-red-600 font-bold">Lumpy Skin: 45 cases</p>
                    </div>
                 </div>
                 <div className="absolute bottom-4 right-4 bg-white/90 p-4 rounded-lg shadow-sm border text-xs text-gray-600">
                    <p className="font-bold mb-2">Legend</p>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2"><span className="w-2 h-2 bg-red-500 rounded-full"></span> High Frequency</div>
                      <div className="flex items-center gap-2"><span className="w-2 h-2 bg-orange-400 rounded-full"></span> Medium Frequency</div>
                      <div className="flex items-center gap-2"><span className="w-2 h-2 bg-green-400 rounded-full"></span> Healthy Zone</div>
                    </div>
                 </div>
              </div>
            </div>

            {/* Outbreaks List */}
            <div className="lg:col-span-1 bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-6 border-b border-gray-100">
                <h2 className="text-lg font-bold text-gray-900">Current Outbreaks</h2>
              </div>
              <div className="divide-y divide-gray-100">
                {outbreaks.map((ob) => (
                  <div key={ob.id} className="p-6">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-bold text-gray-900">{ob.disease}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        ob.status === 'Active' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                      }`}>
                        {ob.status}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-gray-500">{ob.region}</span>
                      <span className="font-bold text-gray-900">{ob.cases} Cases</span>
                    </div>
                    <div className="mt-4 w-full bg-gray-100 rounded-full h-1.5">
                      <div className="bg-red-500 h-1.5 rounded-full" style={{ width: `${(ob.cases / 100) * 100}%` }}></div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="p-6 bg-gray-50 text-center">
                <button className="text-sm font-bold text-green-600 hover:text-green-700">Manage All Outbreaks</button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
