'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';

type Role = 'farmer' | 'veterinarian' | 'admin';

interface User {
  id: number;
  name: string;
  email: string;
  role: Role;
}

interface AuthContextType {
  user: User | null;
  login: (role: Role) => void;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const login = (role: Role) => {
    let userData: User;
    if (role === 'farmer') {
      userData = { id: 1, name: 'Rajesh Kumar', email: 'farmer@example.com', role: 'farmer' };
    } else if (role === 'veterinarian') {
      userData = { id: 2, name: 'Dr. Amit Sharma', email: 'vet@example.com', role: 'veterinarian' };
    } else {
      userData = { id: 3, name: 'Admin User', email: 'admin@example.com', role: 'admin' };
    }
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
