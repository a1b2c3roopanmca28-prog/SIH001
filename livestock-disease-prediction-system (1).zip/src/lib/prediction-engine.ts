export const DISEASES = [
  {
    id: 1,
    name: 'Lumpy Skin Disease',
    symptoms: ['Fever', 'Skin nodules', 'Reduced milk production', 'Loss of appetite'],
    recommendations: 'Isolate the infected animal. Contact a veterinarian immediately. Avoid sharing feeding/watering equipment.',
    severity: 'High'
  },
  {
    id: 2,
    name: 'Foot and Mouth Disease',
    symptoms: ['Fever', 'Blisters in mouth', 'Lameness', 'Excessive salivation', 'Loss of appetite'],
    recommendations: 'Quarantine and vaccination. Disinfect premises. Soft food and clean water.',
    severity: 'High'
  },
  {
    id: 3,
    name: 'Mastitis',
    symptoms: ['Swollen udder', 'Clotted milk', 'Reduced milk production', 'Pain', 'Heat in udder'],
    recommendations: 'Keep udders clean. Dry cow therapy. Consult a vet for antibiotic treatment.',
    severity: 'Medium'
  },
  {
    id: 4,
    name: 'Milk Fever',
    symptoms: ['Muscle tremors', 'Inability to stand', 'Cold ears', 'Low body temperature'],
    recommendations: 'Calcium gluconate injection (only by professional). Keep animal warm.',
    severity: 'High'
  },
  {
    id: 5,
    name: 'Brucellosis',
    symptoms: ['Abortion', 'Retention of placenta', 'Reduced fertility', 'Joint swelling'],
    recommendations: 'Test and slaughter policy in some regions. Vaccination of calves.',
    severity: 'High'
  }
];

export interface PredictionResult {
  id: number;
  disease: string;
  confidence: number;
  severity: string;
  recommendations: string;
  matchedSymptoms: string[];
}

export function predictDisease(symptoms: string[]): PredictionResult[] {
  const results = DISEASES.map(d => {
    const matched = d.symptoms.filter(s => symptoms.includes(s));
    const score = matched.length / d.symptoms.length;
    
    return {
      id: d.id,
      disease: d.name,
      confidence: Math.round(score * 100),
      severity: d.severity,
      recommendations: d.recommendations,
      matchedSymptoms: matched
    };
  });

  return results
    .filter(r => r.confidence > 0)
    .sort((a, b) => b.confidence - a.confidence);
}
