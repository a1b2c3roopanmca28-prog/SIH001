import { pgTable, text, serial, timestamp, integer, doublePrecision, jsonb, boolean } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull().unique(),
  role: text('role', { enum: ['farmer', 'veterinarian', 'admin'] }).notNull().default('farmer'),
  location: text('location'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const animals = pgTable('animals', {
  id: serial('id').primaryKey(),
  ownerId: integer('owner_id').references(() => users.id).notNull(),
  name: text('name').notNull(),
  type: text('type').notNull(), // Cow, Buffalo, Goat, Sheep, Poultry
  breed: text('breed'),
  age: integer('age'),
  gender: text('gender'),
  weight: doublePrecision('weight'),
  pregnancyStatus: text('pregnancy_status'),
  vaccinationHistory: jsonb('vaccination_history'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const diseases = pgTable('diseases', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  description: text('description'),
  symptoms: jsonb('symptoms').notNull(),
  recommendations: text('recommendations'),
  severity: text('severity', { enum: ['Low', 'Medium', 'High'] }).notNull(),
});

export const cases = pgTable('cases', {
  id: serial('id').primaryKey(),
  animalId: integer('animal_id').references(() => animals.id).notNull(),
  farmerId: integer('farmer_id').references(() => users.id).notNull(),
  vetId: integer('vet_id').references(() => users.id),
  symptoms: jsonb('symptoms').notNull(), // Array of symptom keys
  predictedDiseaseId: integer('predicted_disease_id').references(() => diseases.id),
  actualDiseaseId: integer('actual_disease_id').references(() => diseases.id),
  confidence: doublePrecision('confidence'),
  severity: text('severity'),
  status: text('status', { enum: ['Pending', 'Diagnosed', 'Resolved'] }).notNull().default('Pending'),
  notes: text('notes'),
  imageUrl: text('image_url'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const outbreaks = pgTable('outbreaks', {
  id: serial('id').primaryKey(),
  diseaseId: integer('disease_id').references(() => diseases.id).notNull(),
  location: text('location').notNull(),
  startDate: timestamp('start_date').defaultNow(),
  endDate: timestamp('end_date'),
  active: boolean('active').default(true),
});
