import { db } from './index';
import { users, animals, diseases, cases, outbreaks } from './schema';

async function seed() {
  console.log('Seeding data...');

  // Users
  const farmer = await db.insert(users).values({
    name: 'Rajesh Kumar',
    email: 'farmer@example.com',
    role: 'farmer',
    location: 'Punjab, India',
  }).returning();

  const vet = await db.insert(users).values({
    name: 'Dr. Amit Sharma',
    email: 'vet@example.com',
    role: 'veterinarian',
    location: 'Ludhiana, Punjab',
  }).returning();

  const admin = await db.insert(users).values({
    name: 'Admin User',
    email: 'admin@example.com',
    role: 'admin',
    location: 'Delhi',
  }).returning();

  // Diseases
  const lumpySkin = await db.insert(diseases).values({
    name: 'Lumpy Skin Disease',
    description: 'A viral disease in cattle and water buffalo that causes skin nodules.',
    symptoms: ['Fever', 'Skin nodules', 'Reduced milk production', 'Loss of appetite'],
    recommendations: 'Isolate the infected animal. Contact a veterinarian immediately.',
    severity: 'High',
  }).returning();

  const fmd = await db.insert(diseases).values({
    name: 'Foot and Mouth Disease',
    description: 'A highly contagious viral disease of cloven-hoofed animals.',
    symptoms: ['Fever', 'Blisters in mouth', 'Lameness', 'Excessive salivation'],
    recommendations: 'Quarantine and vaccination. Disinfect premises.',
    severity: 'High',
  }).returning();

  const mastitis = await db.insert(diseases).values({
    name: 'Mastitis',
    description: 'Inflammation of the mammary gland and udder tissue.',
    symptoms: ['Swollen udder', 'Clotted milk', 'Reduced milk production', 'Pain'],
    recommendations: 'Keep udders clean. Use antibiotics as prescribed by a vet.',
    severity: 'Medium',
  }).returning();

  const milkFever = await db.insert(diseases).values({
    name: 'Milk Fever',
    description: 'A metabolic disease caused by low blood calcium.',
    symptoms: ['Muscle tremors', 'Inability to stand', 'Cold ears', 'Low body temperature'],
    recommendations: 'Calcium gluconate injection. Keep animal warm.',
    severity: 'High',
  }).returning();

  const brucellosis = await db.insert(diseases).values({
    name: 'Brucellosis',
    description: 'A bacterial disease that affects cattle and other livestock.',
    symptoms: ['Abortion', 'Retention of placenta', 'Reduced fertility', 'Joint swelling'],
    recommendations: 'Test and slaughter policy. Vaccination of calves.',
    severity: 'High',
  }).returning();

  // Animals
  const cow1 = await db.insert(animals).values({
    ownerId: farmer[0].id,
    name: 'Gauri',
    type: 'Cow',
    breed: 'Gir',
    age: 5,
    gender: 'Female',
    weight: 450,
  }).returning();

  const buffalo1 = await db.insert(animals).values({
    ownerId: farmer[0].id,
    name: 'Shera',
    type: 'Buffalo',
    breed: 'Murrah',
    age: 7,
    gender: 'Female',
    weight: 600,
  }).returning();

  // Cases
  await db.insert(cases).values({
    animalId: cow1[0].id,
    farmerId: farmer[0].id,
    symptoms: ['Fever', 'Skin nodules'],
    predictedDiseaseId: lumpySkin[0].id,
    confidence: 0.86,
    severity: 'High',
    status: 'Pending',
  });

  // Outbreaks
  await db.insert(outbreaks).values({
    diseaseId: lumpySkin[0].id,
    location: 'Punjab, India',
  });

  console.log('Seeding complete!');
}

seed().catch(console.error);
