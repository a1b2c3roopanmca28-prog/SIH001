import { getCurrentUser } from "@/lib/auth";
import { ensureDemoSeed } from "@/lib/seed";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  await ensureDemoSeed();
  const user = await getCurrentUser();

  if (user) {
    redirect("/dashboard");
  }

  redirect("/login");
}
