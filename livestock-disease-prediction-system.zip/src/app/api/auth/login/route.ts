import { createSession, validateCredentials } from "@/lib/auth";
import { ensureDemoSeed } from "@/lib/seed";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  await ensureDemoSeed();

  const body = (await request.json().catch(() => null)) as { email?: string; password?: string } | null;
  const email = body?.email?.trim().toLowerCase();
  const password = body?.password;

  if (!email || !password) {
    return NextResponse.json({ error: "Email and password are required." }, { status: 400 });
  }

  const account = await validateCredentials(email, password);

  if (!account) {
    return NextResponse.json({ error: "Invalid credentials." }, { status: 401 });
  }

  await createSession(account.id);

  return NextResponse.json({
    ok: true,
    user: {
      id: account.id,
      fullName: account.fullName,
      email: account.email,
      role: account.role,
    },
  });
}
