import { db } from "@/db";
import { vaccinations } from "@/db/schema";
import { requireApiUser } from "@/lib/api-auth";
import { eq } from "drizzle-orm";
import { NextResponse } from "next/server";

type Params = { params: Promise<{ id: string }> };

async function getId(params: Params["params"]) {
  const { id } = await params;
  return Number(id);
}

export async function PATCH(request: Request, { params }: Params) {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;
  if (user.role === "farmer") {
    return NextResponse.json({ error: "Only vet/admin can update vaccination records." }, { status: 403 });
  }

  const id = await getId(params);
  const body = (await request.json()) as Partial<{
    vaccineName: string;
    dueDate: string;
    status: "due" | "completed" | "missed";
    notes: string;
  }>;

  const updated = await db
    .update(vaccinations)
    .set({
      vaccineName: body.vaccineName,
      dueDate: body.dueDate ? new Date(body.dueDate) : undefined,
      status: body.status,
      notes: body.notes,
      administeredAt: body.status === "completed" ? new Date() : undefined,
    })
    .where(eq(vaccinations.id, id))
    .returning();

  if (!updated[0]) return NextResponse.json({ error: "Record not found." }, { status: 404 });

  return NextResponse.json({ data: updated[0] });
}

export async function DELETE(_: Request, { params }: Params) {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;
  if (user.role === "farmer") {
    return NextResponse.json({ error: "Only vet/admin can delete vaccination records." }, { status: 403 });
  }

  const id = await getId(params);
  const deleted = await db.delete(vaccinations).where(eq(vaccinations.id, id)).returning({ id: vaccinations.id });

  if (!deleted[0]) return NextResponse.json({ error: "Record not found." }, { status: 404 });

  return NextResponse.json({ ok: true });
}
