import { db } from "@/db";
import { animals, vaccinations } from "@/db/schema";
import { requireApiUser } from "@/lib/api-auth";
import { asc, desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  const rows = await db
    .select({
      id: vaccinations.id,
      animalId: vaccinations.animalId,
      animalName: animals.name,
      vaccineName: vaccinations.vaccineName,
      dueDate: vaccinations.dueDate,
      administeredAt: vaccinations.administeredAt,
      status: vaccinations.status,
      notes: vaccinations.notes,
      createdAt: vaccinations.createdAt,
    })
    .from(vaccinations)
    .innerJoin(animals, eq(vaccinations.animalId, animals.id))
    .where(user.role === "farmer" ? eq(animals.ownerId, user.id) : undefined)
    .orderBy(desc(vaccinations.dueDate), asc(vaccinations.id));

  return NextResponse.json({ data: rows });
}

export async function POST(request: Request) {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  if (user.role === "farmer") {
    return NextResponse.json({ error: "Only vet/admin can create vaccination records." }, { status: 403 });
  }

  const body = (await request.json()) as {
    animalId?: number;
    vaccineName?: string;
    dueDate?: string;
    status?: "due" | "completed" | "missed";
    notes?: string;
  };

  if (!body.animalId || !body.vaccineName || !body.dueDate) {
    return NextResponse.json({ error: "animalId, vaccineName and dueDate are required." }, { status: 400 });
  }

  const inserted = await db
    .insert(vaccinations)
    .values({
      animalId: body.animalId,
      vaccineName: body.vaccineName,
      dueDate: new Date(body.dueDate),
      status: body.status ?? "due",
      notes: body.notes ?? "",
      administeredAt: body.status === "completed" ? new Date() : null,
    })
    .returning();

  return NextResponse.json({ data: inserted[0] }, { status: 201 });
}
