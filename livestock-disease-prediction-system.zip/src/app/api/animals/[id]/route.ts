import { db } from "@/db";
import { animals } from "@/db/schema";
import { requireApiUser } from "@/lib/api-auth";
import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

type Params = { params: Promise<{ id: string }> };

async function getAnimalId(params: Params["params"]) {
  const { id } = await params;
  return Number(id);
}

export async function PATCH(request: Request, { params }: Params) {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  const id = await getAnimalId(params);
  if (!Number.isFinite(id)) return NextResponse.json({ error: "Invalid id." }, { status: 400 });

  const body = (await request.json()) as Partial<{
    name: string;
    breed: string;
    ageMonths: number;
    weightKg: number;
    vaccinationSummary: string;
    notes: string;
    isPregnant: boolean;
    isLactating: boolean;
  }>;

  const constraint = user.role === "farmer" ? and(eq(animals.id, id), eq(animals.ownerId, user.id)) : eq(animals.id, id);

  const updated = await db
    .update(animals)
    .set({
      name: body.name,
      breed: body.breed,
      ageMonths: body.ageMonths,
      weightKg: body.weightKg ? Number(body.weightKg).toFixed(2) : undefined,
      vaccinationSummary: body.vaccinationSummary,
      notes: body.notes,
      isPregnant: body.isPregnant,
      isLactating: body.isLactating,
    })
    .where(constraint)
    .returning();

  if (!updated[0]) {
    return NextResponse.json({ error: "Animal not found or permission denied." }, { status: 404 });
  }

  return NextResponse.json({ data: updated[0] });
}

export async function DELETE(_: Request, { params }: Params) {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  if (user.role === "veterinarian") {
    return NextResponse.json({ error: "Permission denied." }, { status: 403 });
  }

  const id = await getAnimalId(params);
  if (!Number.isFinite(id)) return NextResponse.json({ error: "Invalid id." }, { status: 400 });

  const constraint = user.role === "farmer" ? and(eq(animals.id, id), eq(animals.ownerId, user.id)) : eq(animals.id, id);

  const deleted = await db.delete(animals).where(constraint).returning({ id: animals.id });

  if (!deleted[0]) {
    return NextResponse.json({ error: "Animal not found or permission denied." }, { status: 404 });
  }

  return NextResponse.json({ ok: true });
}
