import { db } from "@/db";
import { animals, users } from "@/db/schema";
import { requireApiUser } from "@/lib/api-auth";
import { and, asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  const whereClause = user.role === "farmer" ? eq(animals.ownerId, user.id) : undefined;

  const rows = await db
    .select({
      id: animals.id,
      tagId: animals.tagId,
      name: animals.name,
      species: animals.species,
      breed: animals.breed,
      ageMonths: animals.ageMonths,
      gender: animals.gender,
      weightKg: animals.weightKg,
      isPregnant: animals.isPregnant,
      isLactating: animals.isLactating,
      vaccinationSummary: animals.vaccinationSummary,
      notes: animals.notes,
      ownerId: animals.ownerId,
      ownerName: users.fullName,
      createdAt: animals.createdAt,
    })
    .from(animals)
    .innerJoin(users, eq(animals.ownerId, users.id))
    .where(whereClause)
    .orderBy(asc(animals.id));

  return NextResponse.json({ data: rows });
}

export async function POST(request: Request) {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  if (user.role === "veterinarian") {
    return NextResponse.json({ error: "Veterinarians can view but not create animals." }, { status: 403 });
  }

  const body = (await request.json()) as {
    ownerId?: number;
    tagId?: string;
    name?: string;
    species?: "cattle" | "buffalo" | "goat" | "sheep" | "poultry";
    breed?: string;
    ageMonths?: number;
    gender?: "male" | "female";
    weightKg?: number;
    isPregnant?: boolean;
    isLactating?: boolean;
    vaccinationSummary?: string;
    notes?: string;
  };

  if (!body.tagId || !body.name || !body.species || !body.breed || !body.gender) {
    return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
  }

  const ownerId = user.role === "admin" ? (body.ownerId ?? user.id) : user.id;

  const inserted = await db
    .insert(animals)
    .values({
      ownerId,
      tagId: body.tagId,
      name: body.name,
      species: body.species,
      breed: body.breed,
      ageMonths: Math.max(1, Number(body.ageMonths ?? 1)),
      gender: body.gender,
      weightKg: Number(body.weightKg ?? 100).toFixed(2),
      isPregnant: Boolean(body.isPregnant),
      isLactating: Boolean(body.isLactating),
      vaccinationSummary: body.vaccinationSummary?.trim() || "Not updated",
      notes: body.notes?.trim() || "",
    })
    .returning();

  return NextResponse.json({ data: inserted[0] }, { status: 201 });
}
