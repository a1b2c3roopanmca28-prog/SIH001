import { db } from "@/db";
import { diseaseCases } from "@/db/schema";
import { requireApiUser } from "@/lib/api-auth";
import { and, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

type Params = { params: Promise<{ id: string }> };

async function getId(params: Params["params"]) {
  const { id } = await params;
  return Number(id);
}

export async function PATCH(request: Request, { params }: Params) {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  const id = await getId(params);
  if (!Number.isFinite(id)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const body = (await request.json()) as Partial<{
    status: "open" | "in_treatment" | "resolved";
    vetDiagnosis: string;
    assignedVetId: number | null;
  }>;

  const constraint =
    user.role === "farmer" ? and(eq(diseaseCases.id, id), eq(diseaseCases.reportedById, user.id)) : eq(diseaseCases.id, id);

  if (user.role === "farmer" && (body.vetDiagnosis || body.assignedVetId !== undefined)) {
    return NextResponse.json({ error: "Only vet/admin can assign diagnosis." }, { status: 403 });
  }

  const updated = await db
    .update(diseaseCases)
    .set({
      status: body.status,
      assignedVetId: body.assignedVetId,
      vetDiagnosis: body.vetDiagnosis,
      updatedAt: new Date(),
    })
    .where(constraint)
    .returning();

  if (!updated[0]) {
    return NextResponse.json({ error: "Case not found or access denied." }, { status: 404 });
  }

  return NextResponse.json({ data: updated[0] });
}

export async function DELETE(_: Request, { params }: Params) {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  const id = await getId(params);
  if (!Number.isFinite(id)) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const constraint =
    user.role === "farmer" ? and(eq(diseaseCases.id, id), eq(diseaseCases.reportedById, user.id)) : eq(diseaseCases.id, id);

  const deleted = await db.delete(diseaseCases).where(constraint).returning({ id: diseaseCases.id });

  if (!deleted[0]) return NextResponse.json({ error: "Case not found or access denied." }, { status: 404 });

  return NextResponse.json({ ok: true });
}
