import { db } from "@/db";
import { animals, diseaseCases, users, type EnvironmentalFactors, type SymptomFlags } from "@/db/schema";
import { requireApiUser } from "@/lib/api-auth";
import { predictDisease } from "@/lib/prediction";
import { and, desc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";

const symptomDefaults: SymptomFlags = {
  fever: false,
  coughing: false,
  nasalDischarge: false,
  diarrhea: false,
  lossOfAppetite: false,
  reducedMilkProduction: false,
  swelling: false,
  skinNodules: false,
  lameness: false,
  excessiveSalivation: false,
  breathingDifficulty: false,
  eyeDischarge: false,
  woundsOrLesions: false,
};

export async function GET() {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  const constraint = user.role === "farmer" ? eq(diseaseCases.reportedById, user.id) : undefined;

  const rows = await db
    .select({
      id: diseaseCases.id,
      animalId: diseaseCases.animalId,
      animalName: animals.name,
      tagId: animals.tagId,
      species: animals.species,
      reportedById: diseaseCases.reportedById,
      reportedByName: users.fullName,
      assignedVetId: diseaseCases.assignedVetId,
      symptomFlags: diseaseCases.symptomFlags,
      environmentalFactors: diseaseCases.environmentalFactors,
      symptomsText: diseaseCases.symptomsText,
      predictedDisease: diseaseCases.predictedDisease,
      confidence: diseaseCases.confidence,
      severity: diseaseCases.severity,
      recommendation: diseaseCases.recommendation,
      status: diseaseCases.status,
      vetDiagnosis: diseaseCases.vetDiagnosis,
      createdAt: diseaseCases.createdAt,
      updatedAt: diseaseCases.updatedAt,
    })
    .from(diseaseCases)
    .innerJoin(animals, eq(diseaseCases.animalId, animals.id))
    .innerJoin(users, eq(diseaseCases.reportedById, users.id))
    .where(constraint)
    .orderBy(desc(diseaseCases.createdAt));

  return NextResponse.json({ data: rows });
}

export async function POST(request: Request) {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  const body = (await request.json()) as {
    animalId?: number;
    symptomsText?: string;
    symptomFlags?: Partial<SymptomFlags>;
    environmentalFactors?: Partial<EnvironmentalFactors>;
    assignedVetId?: number;
  };

  if (!body.animalId) {
    return NextResponse.json({ error: "Animal selection is required." }, { status: 400 });
  }

  const animal = await db
    .select({ id: animals.id, ownerId: animals.ownerId, species: animals.species })
    .from(animals)
    .where(eq(animals.id, body.animalId))
    .limit(1);

  const selectedAnimal = animal[0];
  if (!selectedAnimal) {
    return NextResponse.json({ error: "Animal not found." }, { status: 404 });
  }

  if (user.role === "farmer" && selectedAnimal.ownerId !== user.id) {
    return NextResponse.json({ error: "You can only report your own animals." }, { status: 403 });
  }

  const symptomFlags: SymptomFlags = { ...symptomDefaults, ...(body.symptomFlags ?? {}) };
  const environmentalFactors: EnvironmentalFactors = {
    temperatureC: Number(body.environmentalFactors?.temperatureC ?? 32),
    humidityPct: Number(body.environmentalFactors?.humidityPct ?? 65),
    season: body.environmentalFactors?.season ?? "summer",
    outbreakNearby: Boolean(body.environmentalFactors?.outbreakNearby),
    location: body.environmentalFactors?.location?.trim() || user.location || "Unknown",
  };

  const prediction = predictDisease(selectedAnimal.species, symptomFlags, environmentalFactors);

  const inserted = await db
    .insert(diseaseCases)
    .values({
      animalId: selectedAnimal.id,
      reportedById: user.id,
      assignedVetId: body.assignedVetId,
      symptomsText: body.symptomsText?.trim() || "",
      symptomFlags,
      environmentalFactors,
      predictedDisease: prediction.primaryDisease,
      confidence: prediction.confidence,
      severity: prediction.severity,
      recommendation: prediction.recommendation,
      status: "open",
      vetDiagnosis: null,
    })
    .returning();

  return NextResponse.json({ data: { ...inserted[0], top3: prediction.top3 } }, { status: 201 });
}
