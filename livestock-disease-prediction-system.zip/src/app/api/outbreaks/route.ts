import { db } from "@/db";
import { outbreakAlerts } from "@/db/schema";
import { requireApiUser } from "@/lib/api-auth";
import { desc } from "drizzle-orm";
import { NextResponse } from "next/server";

export async function GET() {
  const { user, unauthorized } = await requireApiUser();
  if (!user) return unauthorized;

  const records = await db.select().from(outbreakAlerts).orderBy(desc(outbreakAlerts.reportedAt)).limit(50);
  return NextResponse.json({ data: records });
}
