"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("farmer@demo.com");
  const [password, setPassword] = useState("demo123");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setLoading(true);

    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const data = (await res.json().catch(() => ({}))) as { error?: string };

    if (!res.ok) {
      setLoading(false);
      setError(data.error || "Login failed");
      return;
    }

    router.replace("/dashboard");
    router.refresh();
  }

  return (
    <main className="min-h-screen bg-slate-950 p-4 text-slate-100 md:p-10">
      <div className="mx-auto grid min-h-[92vh] w-full max-w-6xl overflow-hidden rounded-3xl border border-white/10 bg-slate-900 shadow-2xl md:grid-cols-[1.1fr_0.9fr]">
        <section className="hidden bg-[radial-gradient(circle_at_top,_#0ea5e9,_#0f172a_45%)] p-10 md:flex md:flex-col md:justify-between">
          <div>
            <p className="inline-flex rounded-full border border-white/25 bg-white/10 px-3 py-1 text-xs">SIH128 Prototype</p>
            <h1 className="mt-5 text-4xl font-semibold leading-tight">PashuRakshak AI</h1>
            <p className="mt-4 max-w-md text-sm text-slate-200/90">
              AI-powered livestock disease prediction and herd health management for farmers, veterinarians,
              and district administrators.
            </p>
          </div>
          <ul className="space-y-2 text-sm text-slate-100/90">
            <li>✅ Symptom-based disease prediction</li>
            <li>✅ Farmer and veterinarian dashboards</li>
            <li>✅ Animal records, case management, outbreak alerts</li>
          </ul>
        </section>

        <section className="flex items-center justify-center p-6 md:p-10">
          <form onSubmit={onSubmit} className="w-full max-w-md space-y-5">
            <div>
              <h2 className="text-2xl font-semibold">Welcome back</h2>
              <p className="mt-1 text-sm text-slate-400">Use demo credentials or switch role by changing email.</p>
            </div>

            <div className="rounded-2xl border border-sky-300/30 bg-sky-400/10 p-3 text-xs text-sky-100">
              Demo users: farmer@demo.com, vet@demo.com, admin@demo.com (password: demo123)
            </div>

            <label className="block text-sm">
              <span className="mb-1 block text-slate-300">Email</span>
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                type="email"
                className="w-full rounded-xl border border-white/10 bg-slate-800 px-3 py-2 outline-none ring-sky-400 transition focus:ring"
                required
              />
            </label>

            <label className="block text-sm">
              <span className="mb-1 block text-slate-300">Password</span>
              <input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                type="password"
                className="w-full rounded-xl border border-white/10 bg-slate-800 px-3 py-2 outline-none ring-sky-400 transition focus:ring"
                required
              />
            </label>

            {error ? <p className="rounded-xl bg-red-500/20 p-2 text-sm text-red-200">{error}</p> : null}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-sky-500 px-4 py-2 font-semibold text-white transition hover:bg-sky-400 disabled:opacity-70"
            >
              {loading ? "Signing in..." : "Sign in"}
            </button>

            <p className="text-center text-xs text-slate-500">
              By continuing you agree to demo usage for Smart India Hackathon prototype.
            </p>
            <p className="text-center text-xs text-slate-500">
              <Link className="underline" href="https://www.india.gov.in/" target="_blank">
                Government livestock support portal
              </Link>
            </p>
          </form>
        </section>
      </div>
    </main>
  );
}
