import { db } from "@/db";
import { animals, diseaseCases } from "@/db/schema";
import { CasesManager } from "@/components/cases-manager";
import { requireUser } from "@/lib/auth";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function CasesPage() {
  const user = await requireUser();

  const animalRows = await db
    .select({ id: animals.id, name: animals.name, species: animals.species, tagId: animals.tagId })
    .from(animals)
    .where(user.role === "farmer" ? eq(animals.ownerId, user.id) : undefined)
    .orderBy(animals.id);

  const caseRows = await db
    .select({
      id: diseaseCases.id,
      animalId: diseaseCases.animalId,
      animalName: animals.name,
      species: animals.species,
      symptomsText: diseaseCases.symptomsText,
      predictedDisease: diseaseCases.predictedDisease,
      confidence: diseaseCases.confidence,
      severity: diseaseCases.severity,
      recommendation: diseaseCases.recommendation,
      status: diseaseCases.status,
      vetDiagnosis: diseaseCases.vetDiagnosis,
      createdAt: diseaseCases.createdAt,
    })
    .from(diseaseCases)
    .innerJoin(animals, eq(diseaseCases.animalId, animals.id))
    .where(user.role === "farmer" ? eq(diseaseCases.reportedById, user.id) : undefined)
    .orderBy(desc(diseaseCases.createdAt));

  const serializedCaseRows = caseRows.map((item) => ({
    ...item,
    createdAt: item.createdAt.toISOString(),
  }));

  return (
    <div>
      <header className="mb-4 rounded-3xl bg-white p-5 shadow-sm">
        <h2 className="text-2xl font-semibold">Disease Prediction Cases</h2>
        <p className="mt-1 text-sm text-slate-600">
          AI predicts likely diseases from symptoms, environment, and outbreak context.
        </p>
      </header>

      <CasesManager initialCases={serializedCaseRows} animals={animalRows} role={user.role} />
    </div>
  );
}
