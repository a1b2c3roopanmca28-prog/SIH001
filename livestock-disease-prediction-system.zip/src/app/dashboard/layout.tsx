import { LogoutButton } from "@/components/logout-button";
import { requireUser } from "@/lib/auth";
import { ensureDemoSeed } from "@/lib/seed";
import Link from "next/link";
import { ReactNode } from "react";

export const dynamic = "force-dynamic";

const links = [
  { href: "/dashboard", label: "Overview" },
  { href: "/dashboard/animals", label: "Animals" },
  { href: "/dashboard/cases", label: "Disease Cases" },
  { href: "/dashboard/vaccinations", label: "Vaccinations" },
  { href: "/dashboard/outbreaks", label: "Outbreak Monitor" },
];

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  await ensureDemoSeed();
  const user = await requireUser();

  return (
    <main className="min-h-screen bg-slate-100 text-slate-900">
      <div className="mx-auto grid max-w-7xl gap-4 p-3 md:grid-cols-[260px_1fr] md:p-6">
        <aside className="rounded-3xl bg-slate-950 p-4 text-white shadow-xl md:sticky md:top-6 md:h-[calc(100vh-3rem)]">
          <div className="mb-6">
            <p className="text-xs uppercase tracking-wider text-slate-400">PashuRakshak AI</p>
            <h1 className="mt-1 text-xl font-semibold">Livestock Health</h1>
            <p className="mt-2 rounded-xl bg-white/10 px-3 py-2 text-xs text-slate-200">
              {user.fullName} • {user.role}
            </p>
          </div>

          <nav className="space-y-2">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="block rounded-xl border border-white/5 bg-white/5 px-3 py-2 text-sm transition hover:bg-white/15"
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <div className="mt-6">
            <LogoutButton />
          </div>
        </aside>

        <section className="space-y-4">{children}</section>
      </div>
    </main>
  );
}
