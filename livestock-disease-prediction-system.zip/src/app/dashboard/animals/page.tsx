import { db } from "@/db";
import { animals, users } from "@/db/schema";
import { AnimalsManager } from "@/components/animals-manager";
import { requireUser } from "@/lib/auth";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function AnimalsPage() {
  const user = await requireUser();

  const rows = await db
    .select({
      id: animals.id,
      ownerId: animals.ownerId,
      ownerName: users.fullName,
      tagId: animals.tagId,
      name: animals.name,
      species: animals.species,
      breed: animals.breed,
      ageMonths: animals.ageMonths,
      gender: animals.gender,
      weightKg: animals.weightKg,
      isPregnant: animals.isPregnant,
      isLactating: animals.isLactating,
      vaccinationSummary: animals.vaccinationSummary,
      notes: animals.notes,
      createdAt: animals.createdAt,
    })
    .from(animals)
    .innerJoin(users, eq(animals.ownerId, users.id))
    .where(user.role === "farmer" ? eq(animals.ownerId, user.id) : undefined)
    .orderBy(asc(animals.id));

  return (
    <div>
      <header className="mb-4 rounded-3xl bg-white p-5 shadow-sm">
        <h2 className="text-2xl font-semibold">Animal Management</h2>
        <p className="mt-1 text-sm text-slate-600">
          Register animals, maintain profile history, and keep vaccination status updated.
        </p>
      </header>

      <AnimalsManager initialAnimals={rows} canEdit={user.role !== "veterinarian"} />
    </div>
  );
}
