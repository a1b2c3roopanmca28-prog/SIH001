import { db } from "@/db";
import { animals, diseaseCases, outbreakAlerts, users, vaccinations } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { and, count, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function DashboardOverviewPage() {
  const user = await requireUser();

  const animalFilter = user.role === "farmer" ? eq(animals.ownerId, user.id) : undefined;
  const caseFilter = user.role === "farmer" ? eq(diseaseCases.reportedById, user.id) : undefined;

  const [animalCountRow] = await db.select({ value: count() }).from(animals).where(animalFilter);
  const [caseCountRow] = await db.select({ value: count() }).from(diseaseCases).where(caseFilter);
  const [openCaseRow] = await db
    .select({ value: count() })
    .from(diseaseCases)
    .where(and(caseFilter, eq(diseaseCases.status, "open")));
  const [vaccinationDueRow] = await db
    .select({ value: count() })
    .from(vaccinations)
    .where(eq(vaccinations.status, "due"));

  const recentCases = await db
    .select({
      id: diseaseCases.id,
      disease: diseaseCases.predictedDisease,
      confidence: diseaseCases.confidence,
      severity: diseaseCases.severity,
      status: diseaseCases.status,
      createdAt: diseaseCases.createdAt,
      animalName: animals.name,
      reporter: users.fullName,
    })
    .from(diseaseCases)
    .innerJoin(animals, eq(diseaseCases.animalId, animals.id))
    .innerJoin(users, eq(diseaseCases.reportedById, users.id))
    .where(caseFilter)
    .orderBy(desc(diseaseCases.createdAt))
    .limit(6);

  const outbreaks = await db.select().from(outbreakAlerts).orderBy(desc(outbreakAlerts.reportedAt)).limit(4);

  const stats = [
    { label: "Registered Animals", value: Number(animalCountRow?.value ?? 0), tone: "bg-sky-500" },
    { label: "Total Disease Cases", value: Number(caseCountRow?.value ?? 0), tone: "bg-emerald-500" },
    { label: "Open Cases", value: Number(openCaseRow?.value ?? 0), tone: "bg-amber-500" },
    { label: "Vaccinations Due", value: Number(vaccinationDueRow?.value ?? 0), tone: "bg-rose-500" },
  ];

  return (
    <div className="space-y-4">
      <header className="rounded-3xl bg-white p-5 shadow-sm">
        <p className="text-xs uppercase tracking-wider text-slate-500">Dashboard</p>
        <h2 className="mt-1 text-2xl font-semibold">Welcome, {user.fullName}</h2>
        <p className="mt-1 text-sm text-slate-600">
          AI-assisted livestock monitoring with symptom intelligence and outbreak awareness.
        </p>
      </header>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat) => (
          <article key={stat.label} className="rounded-2xl bg-white p-4 shadow-sm">
            <div className={`h-1.5 w-12 rounded-full ${stat.tone}`} />
            <p className="mt-3 text-sm text-slate-600">{stat.label}</p>
            <p className="text-3xl font-semibold">{stat.value}</p>
          </article>
        ))}
      </section>

      <section className="grid gap-4 xl:grid-cols-[1.3fr_1fr]">
        <article className="rounded-2xl bg-white p-4 shadow-sm">
          <h3 className="text-lg font-semibold">Recent Disease Predictions</h3>
          {recentCases.length === 0 ? (
            <p className="mt-4 rounded-xl border border-dashed border-slate-300 p-4 text-sm text-slate-500">
              No cases yet. Start by reporting symptoms in the Disease Cases section.
            </p>
          ) : (
            <div className="mt-3 space-y-3">
              {recentCases.map((item) => (
                <div key={item.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-medium">{item.animalName} • {item.disease}</p>
                    <span className="rounded-full bg-slate-100 px-2 py-1 text-xs">{item.confidence}% confidence</span>
                  </div>
                  <p className="mt-1 text-slate-600">Severity: {item.severity} • Status: {item.status}</p>
                  <p className="text-xs text-slate-500">Reported by {item.reporter}</p>
                </div>
              ))}
            </div>
          )}
        </article>

        <article className="rounded-2xl bg-white p-4 shadow-sm">
          <h3 className="text-lg font-semibold">Regional Outbreak Pulse</h3>
          <div className="mt-3 space-y-3">
            {outbreaks.map((alert) => (
              <div key={alert.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                <p className="font-medium">{alert.district} • {alert.disease}</p>
                <p className="text-slate-600">Risk: {alert.riskLevel} • Active cases: {alert.activeCases}</p>
                <p className="text-xs text-slate-500">{alert.advisory}</p>
              </div>
            ))}
          </div>
        </article>
      </section>
    </div>
  );
}
