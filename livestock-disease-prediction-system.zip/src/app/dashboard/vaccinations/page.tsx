import { db } from "@/db";
import { animals, vaccinations } from "@/db/schema";
import { VaccinationsManager } from "@/components/vaccinations-manager";
import { requireUser } from "@/lib/auth";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function VaccinationsPage() {
  const user = await requireUser();

  const animalRows = await db
    .select({ id: animals.id, name: animals.name, tagId: animals.tagId })
    .from(animals)
    .where(user.role === "farmer" ? eq(animals.ownerId, user.id) : undefined)
    .orderBy(animals.id);

  const records = await db
    .select({
      id: vaccinations.id,
      animalId: vaccinations.animalId,
      animalName: animals.name,
      vaccineName: vaccinations.vaccineName,
      dueDate: vaccinations.dueDate,
      status: vaccinations.status,
      notes: vaccinations.notes,
    })
    .from(vaccinations)
    .innerJoin(animals, eq(vaccinations.animalId, animals.id))
    .where(user.role === "farmer" ? eq(animals.ownerId, user.id) : undefined)
    .orderBy(desc(vaccinations.dueDate));

  const serializedRecords = records.map((record) => ({
    ...record,
    dueDate: record.dueDate.toISOString(),
  }));

  return (
    <div>
      <header className="mb-4 rounded-3xl bg-white p-5 shadow-sm">
        <h2 className="text-2xl font-semibold">Vaccination & Deworming Tracker</h2>
        <p className="mt-1 text-sm text-slate-600">Set reminders and monitor compliance to reduce outbreaks.</p>
      </header>

      <VaccinationsManager initialData={serializedRecords} animals={animalRows} canManage={user.role !== "farmer"} />
    </div>
  );
}
