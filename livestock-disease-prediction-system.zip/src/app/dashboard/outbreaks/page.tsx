import { db } from "@/db";
import { outbreakAlerts } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function OutbreaksPage() {
  await requireUser();

  const alerts = await db.select().from(outbreakAlerts).orderBy(desc(outbreakAlerts.reportedAt));

  return (
    <div>
      <header className="mb-4 rounded-3xl bg-white p-5 shadow-sm">
        <h2 className="text-2xl font-semibold">Regional Outbreak Monitor</h2>
        <p className="mt-1 text-sm text-slate-600">
          Cluster-level disease alerts for rapid containment planning and veterinarian mobilization.
        </p>
      </header>

      <section className="rounded-2xl bg-white p-4 shadow-sm">
        {alerts.length === 0 ? (
          <p className="rounded-xl border border-dashed border-slate-300 p-4 text-sm text-slate-500">
            No active alerts currently.
          </p>
        ) : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {alerts.map((alert) => (
              <article key={alert.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-semibold">{alert.district}</p>
                  <span
                    className={`rounded-full px-2 py-1 text-xs ${
                      alert.riskLevel === "high"
                        ? "bg-rose-100 text-rose-700"
                        : alert.riskLevel === "moderate"
                          ? "bg-amber-100 text-amber-700"
                          : "bg-emerald-100 text-emerald-700"
                    }`}
                  >
                    {alert.riskLevel}
                  </span>
                </div>
                <p className="mt-1 text-slate-700">{alert.disease}</p>
                <p className="text-slate-500">Active cases: {alert.activeCases}</p>
                <p className="mt-2 text-xs text-slate-500">{alert.advisory}</p>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
