import type { EnvironmentalFactors, SymptomFlags } from "@/db/schema";

type DiseaseProfile = {
  name: string;
  species: Array<"cattle" | "buffalo" | "goat" | "sheep" | "poultry">;
  weights: Partial<Record<keyof SymptomFlags, number>>;
  base: number;
  recommendation: string;
  severeTriggers: Array<keyof SymptomFlags>;
};

const DISEASE_PROFILES: DiseaseProfile[] = [
  {
    name: "Foot and Mouth Disease",
    species: ["cattle", "buffalo", "goat", "sheep"],
    base: 12,
    weights: {
      fever: 15,
      excessiveSalivation: 22,
      lameness: 20,
      woundsOrLesions: 18,
      lossOfAppetite: 10,
    },
    severeTriggers: ["excessiveSalivation", "lameness", "woundsOrLesions"],
    recommendation:
      "Isolate the animal immediately, disinfect feeding tools, and arrange urgent veterinary examination.",
  },
  {
    name: "Mastitis",
    species: ["cattle", "buffalo"],
    base: 10,
    weights: {
      swelling: 24,
      reducedMilkProduction: 25,
      fever: 12,
      lossOfAppetite: 10,
    },
    severeTriggers: ["swelling", "reducedMilkProduction"],
    recommendation:
      "Maintain udder hygiene, milk out affected quarter carefully, and consult vet for antibiotic protocol.",
  },
  {
    name: "Lumpy Skin Disease",
    species: ["cattle", "buffalo"],
    base: 14,
    weights: {
      fever: 15,
      skinNodules: 30,
      eyeDischarge: 10,
      reducedMilkProduction: 15,
      lossOfAppetite: 10,
    },
    severeTriggers: ["skinNodules", "fever"],
    recommendation:
      "Quarantine the animal, control insects, and alert nearby farmers and local veterinary services.",
  },
  {
    name: "Bovine Respiratory Disease",
    species: ["cattle", "buffalo"],
    base: 10,
    weights: {
      fever: 13,
      coughing: 20,
      nasalDischarge: 17,
      breathingDifficulty: 20,
      eyeDischarge: 8,
    },
    severeTriggers: ["breathingDifficulty", "fever"],
    recommendation:
      "Keep in well-ventilated space, reduce stress, and start veterinary-supported respiratory treatment quickly.",
  },
  {
    name: "Tick Fever",
    species: ["cattle", "buffalo", "goat", "sheep"],
    base: 8,
    weights: {
      fever: 18,
      lossOfAppetite: 10,
      eyeDischarge: 8,
      lameness: 12,
    },
    severeTriggers: ["fever"],
    recommendation:
      "Apply tick control measures, inspect herd, and contact vet for blood parasite management.",
  },
  {
    name: "Enteritis / Diarrheal Disease",
    species: ["cattle", "buffalo", "goat", "sheep", "poultry"],
    base: 10,
    weights: {
      diarrhea: 28,
      fever: 10,
      lossOfAppetite: 12,
      swelling: 6,
    },
    severeTriggers: ["diarrhea", "lossOfAppetite"],
    recommendation:
      "Start oral rehydration, maintain clean water, and seek veterinary testing if dehydration worsens.",
  },
  {
    name: "Newcastle Disease",
    species: ["poultry"],
    base: 12,
    weights: {
      breathingDifficulty: 18,
      diarrhea: 15,
      coughing: 10,
      excessiveSalivation: 9,
      lossOfAppetite: 8,
    },
    severeTriggers: ["breathingDifficulty", "diarrhea"],
    recommendation:
      "Separate flock, sanitize sheds, and notify veterinary authority due to high transmission risk.",
  },
];

export function predictDisease(
  species: "cattle" | "buffalo" | "goat" | "sheep" | "poultry",
  symptoms: SymptomFlags,
  environment: EnvironmentalFactors,
) {
  const candidates = DISEASE_PROFILES.filter((d) => d.species.includes(species)).map((profile) => {
    let score = profile.base;

    for (const [symptom, active] of Object.entries(symptoms) as Array<[keyof SymptomFlags, boolean]>) {
      if (active) {
        score += profile.weights[symptom] ?? 0;
      }
    }

    if (environment.outbreakNearby) score += 8;
    if (environment.humidityPct > 75) score += 4;
    if (environment.temperatureC > 35) score += 3;

    return { profile, score };
  });

  const total = candidates.reduce((sum, item) => sum + item.score, 0) || 1;
  const ranked = candidates
    .map(({ profile, score }) => ({
      disease: profile.name,
      probability: Math.max(1, Math.round((score / total) * 100)),
      recommendation: profile.recommendation,
      severeMatchCount: profile.severeTriggers.filter((key) => symptoms[key]).length,
    }))
    .sort((a, b) => b.probability - a.probability);

  const top = ranked[0];
  const severity =
    top.probability > 55 || top.severeMatchCount >= 2
      ? "high"
      : top.probability > 40
        ? "moderate"
        : "low";

  return {
    primaryDisease: top.disease,
    confidence: Math.min(99, top.probability),
    severity: severity as "low" | "moderate" | "high" | "critical",
    recommendation: top.recommendation,
    top3: ranked.slice(0, 3),
  };
}
