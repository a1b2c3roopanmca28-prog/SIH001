import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { createHash, randomBytes } from "node:crypto";

export const SESSION_COOKIE = "livestock_session";

export function hashPassword(password: string) {
  return createHash("sha256").update(password).digest("hex");
}

export type AuthUser = {
  id: number;
  fullName: string;
  email: string;
  role: "farmer" | "veterinarian" | "admin";
  location: string | null;
};

export async function createSession(userId: number) {
  const token = randomBytes(48).toString("hex");
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 7);

  await db.insert(sessions).values({ token, userId, expiresAt });

  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });
}

export async function clearSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;

  if (token) {
    await db.delete(sessions).where(eq(sessions.token, token));
  }

  cookieStore.delete(SESSION_COOKIE);
}

export async function getCurrentUser(): Promise<AuthUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;

  if (!token) return null;

  const found = await db
    .select({
      sessionId: sessions.id,
      userId: users.id,
      fullName: users.fullName,
      email: users.email,
      role: users.role,
      location: users.location,
      expiresAt: sessions.expiresAt,
    })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(eq(sessions.token, token))
    .limit(1);

  const row = found[0];
  if (!row) return null;

  if (new Date(row.expiresAt).getTime() < Date.now()) {
    await db.delete(sessions).where(eq(sessions.id, row.sessionId));
    cookieStore.delete(SESSION_COOKIE);
    return null;
  }

  return {
    id: row.userId,
    fullName: row.fullName,
    email: row.email,
    role: row.role,
    location: row.location,
  };
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

export async function requireRole(allowed: Array<AuthUser["role"]>) {
  const user = await requireUser();
  if (!allowed.includes(user.role)) {
    redirect("/dashboard");
  }
  return user;
}

export async function validateCredentials(email: string, password: string) {
  const found = await db
    .select({
      id: users.id,
      fullName: users.fullName,
      email: users.email,
      role: users.role,
      passwordHash: users.passwordHash,
    })
    .from(users)
    .where(eq(users.email, email.trim().toLowerCase()))
    .limit(1);

  const account = found[0];
  if (!account) return null;

  if (account.passwordHash !== hashPassword(password)) return null;

  return {
    id: account.id,
    fullName: account.fullName,
    email: account.email,
    role: account.role,
  };
}
