import { db } from "@/db";
import {
  animals,
  diseaseCases,
  outbreakAlerts,
  users,
  vaccinations,
  type EnvironmentalFactors,
  type SymptomFlags,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { predictDisease } from "@/lib/prediction";
import { count, eq } from "drizzle-orm";

const DEFAULT_SYMPTOMS: SymptomFlags = {
  fever: false,
  coughing: false,
  nasalDischarge: false,
  diarrhea: false,
  lossOfAppetite: false,
  reducedMilkProduction: false,
  swelling: false,
  skinNodules: false,
  lameness: false,
  excessiveSalivation: false,
  breathingDifficulty: false,
  eyeDischarge: false,
  woundsOrLesions: false,
};

export async function ensureDemoSeed() {
  const existing = await db.select({ value: count() }).from(users);
  if ((existing[0]?.value ?? 0) > 0) return;

  const [farmer] = await db
    .insert(users)
    .values({
      fullName: "Ramesh Patel",
      email: "farmer@demo.com",
      passwordHash: hashPassword("demo123"),
      role: "farmer",
      phone: "+91-9876543210",
      location: "Anand, Gujarat",
      preferredLanguage: "Hindi",
    })
    .returning();

  const [vet] = await db
    .insert(users)
    .values({
      fullName: "Dr. Kavita Sharma",
      email: "vet@demo.com",
      passwordHash: hashPassword("demo123"),
      role: "veterinarian",
      phone: "+91-9123456780",
      location: "Anand, Gujarat",
      preferredLanguage: "English",
    })
    .returning();

  await db.insert(users).values({
    fullName: "District Admin",
    email: "admin@demo.com",
    passwordHash: hashPassword("demo123"),
    role: "admin",
    phone: "+91-9000001111",
    location: "Anand, Gujarat",
    preferredLanguage: "English",
  });

  const seededAnimals = await db
    .insert(animals)
    .values([
      {
        ownerId: farmer.id,
        tagId: "GJ-AN-001",
        name: "Gauri",
        species: "cattle",
        breed: "Gir",
        ageMonths: 60,
        gender: "female",
        weightKg: "430.50",
        isPregnant: false,
        isLactating: true,
        vaccinationSummary: "FMD vaccine updated in Jan 2026",
        notes: "High milk yield dairy cow",
      },
      {
        ownerId: farmer.id,
        tagId: "GJ-AN-002",
        name: "Nandi",
        species: "buffalo",
        breed: "Murrah",
        ageMonths: 72,
        gender: "female",
        weightKg: "520.00",
        isPregnant: true,
        isLactating: false,
        vaccinationSummary: "Brucellosis and deworming completed",
        notes: "2nd trimester",
      },
      {
        ownerId: farmer.id,
        tagId: "GJ-AN-003",
        name: "Moti",
        species: "cattle",
        breed: "Sahiwal",
        ageMonths: 38,
        gender: "female",
        weightKg: "360.75",
        isPregnant: false,
        isLactating: true,
        vaccinationSummary: "Pending BQ booster",
        notes: "Recent appetite drop",
      },
    ])
    .returning();

  const env: EnvironmentalFactors = {
    location: "Anand, Gujarat",
    humidityPct: 81,
    season: "monsoon",
    temperatureC: 33,
    outbreakNearby: true,
  };

  const case1Symptoms: SymptomFlags = {
    ...DEFAULT_SYMPTOMS,
    fever: true,
    skinNodules: true,
    reducedMilkProduction: true,
    lossOfAppetite: true,
  };
  const pred1 = predictDisease("cattle", case1Symptoms, env);

  const case2Symptoms: SymptomFlags = {
    ...DEFAULT_SYMPTOMS,
    fever: true,
    swelling: true,
    reducedMilkProduction: true,
  };
  const pred2 = predictDisease("buffalo", case2Symptoms, {
    ...env,
    outbreakNearby: false,
    humidityPct: 62,
  });

  await db.insert(diseaseCases).values([
    {
      animalId: seededAnimals[0].id,
      reportedById: farmer.id,
      assignedVetId: vet.id,
      symptomFlags: case1Symptoms,
      environmentalFactors: env,
      symptomsText: "Skin nodules on neck, mild fever since 2 days, milk dropped by 20%.",
      predictedDisease: pred1.primaryDisease,
      confidence: pred1.confidence,
      severity: pred1.severity,
      recommendation: pred1.recommendation,
      status: "in_treatment",
      vetDiagnosis: "Likely LSD. Continue supportive therapy and vector control.",
    },
    {
      animalId: seededAnimals[1].id,
      reportedById: farmer.id,
      assignedVetId: vet.id,
      symptomFlags: case2Symptoms,
      environmentalFactors: { ...env, outbreakNearby: false, humidityPct: 62 },
      symptomsText: "Udder swelling and low milk output",
      predictedDisease: pred2.primaryDisease,
      confidence: pred2.confidence,
      severity: pred2.severity,
      recommendation: pred2.recommendation,
      status: "open",
      vetDiagnosis: null,
    },
  ]);

  await db.insert(vaccinations).values([
    {
      animalId: seededAnimals[0].id,
      vaccineName: "FMD Booster",
      dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 25),
      status: "due",
      notes: "Schedule at local camp",
    },
    {
      animalId: seededAnimals[2].id,
      vaccineName: "Black Quarter Booster",
      dueDate: new Date(Date.now() + 1000 * 60 * 60 * 24 * 8),
      status: "due",
      notes: "High-risk season reminder",
    },
  ]);

  await db.insert(outbreakAlerts).values([
    {
      district: "Anand",
      disease: "Lumpy Skin Disease",
      riskLevel: "high",
      activeCases: 14,
      advisory: "Restrict animal movement and increase insect control near water bodies.",
    },
    {
      district: "Kheda",
      disease: "Foot and Mouth Disease",
      riskLevel: "moderate",
      activeCases: 6,
      advisory: "Ensure ring vaccination and hygiene protocols in shared grazing zones.",
    },
  ]);
}

export async function getDefaultFarmerId() {
  const farmer = await db.select({ id: users.id }).from(users).where(eq(users.email, "farmer@demo.com")).limit(1);
  return farmer[0]?.id ?? null;
}
