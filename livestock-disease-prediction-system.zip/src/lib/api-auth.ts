import { getCurrentUser } from "@/lib/auth";
import { NextResponse } from "next/server";

export async function requireApiUser() {
  const user = await getCurrentUser();
  if (!user) {
    return { user: null, unauthorized: NextResponse.json({ error: "Unauthorized" }, { status: 401 }) };
  }
  return { user, unauthorized: null };
}
