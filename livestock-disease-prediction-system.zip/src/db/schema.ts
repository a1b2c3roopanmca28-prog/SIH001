import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  uuid,
  varchar,
} from "drizzle-orm/pg-core";

export const userRoleEnum = pgEnum("user_role", ["farmer", "veterinarian", "admin"]);
export const speciesEnum = pgEnum("species", ["cattle", "buffalo", "goat", "sheep", "poultry"]);
export const genderEnum = pgEnum("gender", ["male", "female"]);
export const severityEnum = pgEnum("severity", ["low", "moderate", "high", "critical"]);
export const caseStatusEnum = pgEnum("case_status", ["open", "in_treatment", "resolved"]);
export const vaccinationStatusEnum = pgEnum("vaccination_status", ["due", "completed", "missed"]);
export const riskLevelEnum = pgEnum("risk_level", ["low", "moderate", "high"]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  fullName: varchar("full_name", { length: 120 }).notNull(),
  email: varchar("email", { length: 160 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: userRoleEnum("role").notNull().default("farmer"),
  phone: varchar("phone", { length: 20 }),
  location: varchar("location", { length: 120 }),
  preferredLanguage: varchar("preferred_language", { length: 40 }).notNull().default("English"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  token: varchar("token", { length: 128 }).notNull().unique(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const animals = pgTable("animals", {
  id: serial("id").primaryKey(),
  ownerId: integer("owner_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  tagId: varchar("tag_id", { length: 80 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  species: speciesEnum("species").notNull(),
  breed: varchar("breed", { length: 100 }).notNull(),
  ageMonths: integer("age_months").notNull(),
  gender: genderEnum("gender").notNull(),
  weightKg: numeric("weight_kg", { precision: 6, scale: 2 }).notNull(),
  isPregnant: boolean("is_pregnant").notNull().default(false),
  isLactating: boolean("is_lactating").notNull().default(false),
  vaccinationSummary: text("vaccination_summary").notNull().default("Up to date"),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type SymptomFlags = {
  fever: boolean;
  coughing: boolean;
  nasalDischarge: boolean;
  diarrhea: boolean;
  lossOfAppetite: boolean;
  reducedMilkProduction: boolean;
  swelling: boolean;
  skinNodules: boolean;
  lameness: boolean;
  excessiveSalivation: boolean;
  breathingDifficulty: boolean;
  eyeDischarge: boolean;
  woundsOrLesions: boolean;
};

export type EnvironmentalFactors = {
  temperatureC: number;
  humidityPct: number;
  season: "summer" | "monsoon" | "winter" | "spring";
  outbreakNearby: boolean;
  location: string;
};

export const diseaseCases = pgTable("disease_cases", {
  id: serial("id").primaryKey(),
  animalId: integer("animal_id")
    .notNull()
    .references(() => animals.id, { onDelete: "cascade" }),
  reportedById: integer("reported_by_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  assignedVetId: integer("assigned_vet_id").references(() => users.id, { onDelete: "set null" }),
  symptomFlags: jsonb("symptom_flags").$type<SymptomFlags>().notNull(),
  environmentalFactors: jsonb("environmental_factors").$type<EnvironmentalFactors>().notNull(),
  symptomsText: text("symptoms_text").notNull().default(""),
  predictedDisease: varchar("predicted_disease", { length: 140 }).notNull(),
  confidence: integer("confidence").notNull(),
  severity: severityEnum("severity").notNull(),
  recommendation: text("recommendation").notNull(),
  status: caseStatusEnum("status").notNull().default("open"),
  vetDiagnosis: text("vet_diagnosis"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const vaccinations = pgTable("vaccinations", {
  id: serial("id").primaryKey(),
  animalId: integer("animal_id")
    .notNull()
    .references(() => animals.id, { onDelete: "cascade" }),
  vaccineName: varchar("vaccine_name", { length: 120 }).notNull(),
  dueDate: timestamp("due_date", { withTimezone: true }).notNull(),
  administeredAt: timestamp("administered_at", { withTimezone: true }),
  status: vaccinationStatusEnum("status").notNull().default("due"),
  notes: text("notes").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const outbreakAlerts = pgTable("outbreak_alerts", {
  id: serial("id").primaryKey(),
  district: varchar("district", { length: 120 }).notNull(),
  disease: varchar("disease", { length: 140 }).notNull(),
  riskLevel: riskLevelEnum("risk_level").notNull(),
  activeCases: integer("active_cases").notNull().default(0),
  advisory: text("advisory").notNull(),
  reportedAt: timestamp("reported_at", { withTimezone: true }).notNull().defaultNow(),
});
