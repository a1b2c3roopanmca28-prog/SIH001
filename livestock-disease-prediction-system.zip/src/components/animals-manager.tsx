"use client";

import { useMemo, useState, useTransition } from "react";

type Animal = {
  id: number;
  ownerId: number;
  ownerName?: string;
  tagId: string;
  name: string;
  species: "cattle" | "buffalo" | "goat" | "sheep" | "poultry";
  breed: string;
  ageMonths: number;
  gender: "male" | "female";
  weightKg: string;
  isPregnant: boolean;
  isLactating: boolean;
  vaccinationSummary: string;
  notes: string;
};

export function AnimalsManager({
  initialAnimals,
  canEdit,
}: {
  initialAnimals: Animal[];
  canEdit: boolean;
}) {
  const [animals, setAnimals] = useState(initialAnimals);
  const [selected, setSelected] = useState<Animal | null>(null);
  const [message, setMessage] = useState("");
  const [isPending, startTransition] = useTransition();

  const summary = useMemo(() => {
    const cattle = animals.filter((a) => a.species === "cattle").length;
    const buffalo = animals.filter((a) => a.species === "buffalo").length;
    return { total: animals.length, cattle, buffalo };
  }, [animals]);

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-3">
        <StatCard label="Total Animals" value={summary.total} />
        <StatCard label="Cattle" value={summary.cattle} />
        <StatCard label="Buffalo" value={summary.buffalo} />
      </div>

      {canEdit ? (
        <AnimalForm
          key={selected?.id ?? "new"}
          selected={selected}
          busy={isPending}
          onCancel={() => setSelected(null)}
          onSave={(payload) => {
            setMessage("");
            startTransition(async () => {
              if (selected) {
                const prev = animals;
                setAnimals((curr) => curr.map((a) => (a.id === selected.id ? { ...a, ...payload } as Animal : a)));

                const res = await fetch(`/api/animals/${selected.id}`, {
                  method: "PATCH",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify(payload),
                });

                if (!res.ok) {
                  setAnimals(prev);
                  setMessage("Failed to update animal.");
                  return;
                }

                const data = (await res.json()) as { data: Animal };
                setAnimals((curr) => curr.map((a) => (a.id === selected.id ? data.data : a)));
                setSelected(null);
                setMessage("Animal updated.");
              } else {
                const temp: Animal = {
                  id: -Date.now(),
                  ownerId: 0,
                  tagId: payload.tagId!,
                  name: payload.name!,
                  species: payload.species!,
                  breed: payload.breed!,
                  ageMonths: payload.ageMonths!,
                  gender: payload.gender!,
                  weightKg: String(payload.weightKg),
                  isPregnant: Boolean(payload.isPregnant),
                  isLactating: Boolean(payload.isLactating),
                  vaccinationSummary: payload.vaccinationSummary || "Not updated",
                  notes: payload.notes || "",
                };

                setAnimals((curr) => [temp, ...curr]);

                const res = await fetch("/api/animals", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify(payload),
                });

                if (!res.ok) {
                  setAnimals((curr) => curr.filter((a) => a.id !== temp.id));
                  setMessage("Failed to create animal.");
                  return;
                }

                const data = (await res.json()) as { data: Animal };
                setAnimals((curr) => [data.data, ...curr.filter((a) => a.id !== temp.id)]);
                setMessage("Animal created.");
              }
            });
          }}
        />
      ) : (
        <p className="rounded-xl border border-dashed border-slate-300 bg-white p-3 text-sm text-slate-600">
          Veterinarian role has read-only access for animals.
        </p>
      )}

      {message ? <p className="text-sm text-slate-600">{message}</p> : null}

      <div className="rounded-2xl bg-white p-4 shadow-sm">
        <h3 className="text-lg font-semibold">Livestock Registry</h3>
        {animals.length === 0 ? (
          <p className="mt-3 rounded-xl border border-dashed border-slate-300 p-4 text-sm text-slate-500">
            No animals yet. Add your first animal profile to start disease tracking.
          </p>
        ) : (
          <div className="mt-3 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {animals.map((animal) => (
              <article key={animal.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold">{animal.name}</p>
                    <p className="text-xs text-slate-500">Tag {animal.tagId}</p>
                  </div>
                  <span className="rounded-full bg-slate-100 px-2 py-1 text-xs">{animal.species}</span>
                </div>
                <p className="mt-2 text-slate-600">{animal.breed} • {animal.ageMonths} months • {animal.weightKg} kg</p>
                <p className="text-slate-500">Vaccination: {animal.vaccinationSummary}</p>
                {animal.notes ? <p className="mt-1 text-xs text-slate-500">{animal.notes}</p> : null}

                {canEdit ? (
                  <div className="mt-3 flex gap-2">
                    <button
                      className="rounded-lg border border-slate-300 px-2 py-1 text-xs hover:bg-slate-100"
                      onClick={() => setSelected(animal)}
                    >
                      Edit
                    </button>
                    <button
                      className="rounded-lg border border-rose-300 px-2 py-1 text-xs text-rose-700 hover:bg-rose-50"
                      onClick={() => {
                        const prev = animals;
                        setAnimals((curr) => curr.filter((a) => a.id !== animal.id));
                        startTransition(async () => {
                          const res = await fetch(`/api/animals/${animal.id}`, { method: "DELETE" });
                          if (!res.ok) {
                            setAnimals(prev);
                            setMessage("Delete failed.");
                          } else {
                            setMessage("Animal removed.");
                          }
                        });
                      }}
                    >
                      Delete
                    </button>
                  </div>
                ) : null}
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl bg-white p-4 shadow-sm">
      <p className="text-sm text-slate-600">{label}</p>
      <p className="text-2xl font-semibold">{value}</p>
    </div>
  );
}

function AnimalForm({
  selected,
  onSave,
  onCancel,
  busy,
}: {
  selected: Animal | null;
  busy: boolean;
  onCancel: () => void;
  onSave: (payload: {
    tagId?: string;
    name?: string;
    species?: Animal["species"];
    breed?: string;
    ageMonths?: number;
    gender?: Animal["gender"];
    weightKg?: number;
    isPregnant?: boolean;
    isLactating?: boolean;
    vaccinationSummary?: string;
    notes?: string;
  }) => void;
}) {
  const [tagId, setTagId] = useState(selected?.tagId ?? "");
  const [name, setName] = useState(selected?.name ?? "");
  const [species, setSpecies] = useState<Animal["species"]>(selected?.species ?? "cattle");
  const [breed, setBreed] = useState(selected?.breed ?? "");
  const [ageMonths, setAgeMonths] = useState(selected?.ageMonths ?? 24);
  const [gender, setGender] = useState<Animal["gender"]>(selected?.gender ?? "female");
  const [weightKg, setWeightKg] = useState(Number(selected?.weightKg ?? 300));
  const [isPregnant, setIsPregnant] = useState(selected?.isPregnant ?? false);
  const [isLactating, setIsLactating] = useState(selected?.isLactating ?? true);
  const [vaccinationSummary, setVaccinationSummary] = useState(selected?.vaccinationSummary ?? "");
  const [notes, setNotes] = useState(selected?.notes ?? "");

  return (
    <form
      className="rounded-2xl bg-white p-4 shadow-sm"
      onSubmit={(e) => {
        e.preventDefault();
        onSave({
          tagId,
          name,
          species,
          breed,
          ageMonths,
          gender,
          weightKg,
          isPregnant,
          isLactating,
          vaccinationSummary,
          notes,
        });
      }}
    >
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-lg font-semibold">{selected ? "Edit Animal" : "Add New Animal"}</h3>
        {selected ? (
          <button type="button" className="text-xs text-slate-500 underline" onClick={onCancel}>
            Cancel edit
          </button>
        ) : null}
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        <Input label="Tag ID" value={tagId} onChange={setTagId} required={!selected} />
        <Input label="Name" value={name} onChange={setName} required />
        <Select label="Species" value={species} onChange={(v) => setSpecies(v as Animal["species"])} options={["cattle", "buffalo", "goat", "sheep", "poultry"]} />
        <Input label="Breed" value={breed} onChange={setBreed} required />
        <Input label="Age (months)" value={String(ageMonths)} onChange={(v) => setAgeMonths(Number(v || 0))} type="number" />
        <Select label="Gender" value={gender} onChange={(v) => setGender(v as Animal["gender"])} options={["female", "male"]} />
        <Input label="Weight (kg)" value={String(weightKg)} onChange={(v) => setWeightKg(Number(v || 0))} type="number" />
        <Input label="Vaccination Summary" value={vaccinationSummary} onChange={setVaccinationSummary} />
      </div>

      <label className="mt-3 block text-sm">
        Notes
        <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2" rows={2} />
      </label>

      <div className="mt-3 flex flex-wrap gap-4 text-sm">
        <label className="inline-flex items-center gap-2">
          <input checked={isPregnant} onChange={(e) => setIsPregnant(e.target.checked)} type="checkbox" /> Pregnant
        </label>
        <label className="inline-flex items-center gap-2">
          <input checked={isLactating} onChange={(e) => setIsLactating(e.target.checked)} type="checkbox" /> Lactating
        </label>
      </div>

      <button disabled={busy} className="mt-4 rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-70">
        {busy ? "Saving..." : selected ? "Update Animal" : "Create Animal"}
      </button>
    </form>
  );
}

function Input({
  label,
  value,
  onChange,
  type = "text",
  required = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
}) {
  return (
    <label className="block text-sm">
      {label}
      <input
        required={required}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        type={type}
        className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2"
      />
    </label>
  );
}

function Select({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: string[];
}) {
  return (
    <label className="block text-sm">
      {label}
      <select value={value} onChange={(e) => onChange(e.target.value)} className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2">
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </label>
  );
}
