"use client";

import { useState, useTransition } from "react";

type AnimalOption = {
  id: number;
  name: string;
  species: "cattle" | "buffalo" | "goat" | "sheep" | "poultry";
  tagId: string;
};

type CaseItem = {
  id: number;
  animalId: number;
  animalName: string;
  species: string;
  symptomsText: string;
  predictedDisease: string;
  confidence: number;
  severity: "low" | "moderate" | "high" | "critical";
  recommendation: string;
  status: "open" | "in_treatment" | "resolved";
  vetDiagnosis: string | null;
  createdAt: string;
};

const symptomKeys = [
  "fever",
  "coughing",
  "nasalDischarge",
  "diarrhea",
  "lossOfAppetite",
  "reducedMilkProduction",
  "swelling",
  "skinNodules",
  "lameness",
  "excessiveSalivation",
  "breathingDifficulty",
  "eyeDischarge",
  "woundsOrLesions",
] as const;

export function CasesManager({
  initialCases,
  animals,
  role,
}: {
  initialCases: CaseItem[];
  animals: AnimalOption[];
  role: "farmer" | "veterinarian" | "admin";
}) {
  const [records, setRecords] = useState(initialCases);
  const [pending, startTransition] = useTransition();
  const [message, setMessage] = useState("");

  const [animalId, setAnimalId] = useState(String(animals[0]?.id ?? ""));
  const [symptomsText, setSymptomsText] = useState("");
  const [location, setLocation] = useState("Anand, Gujarat");
  const [temperatureC, setTemperatureC] = useState(33);
  const [humidityPct, setHumidityPct] = useState(78);
  const [season, setSeason] = useState<"summer" | "monsoon" | "winter" | "spring">("monsoon");
  const [outbreakNearby, setOutbreakNearby] = useState(true);
  const [symptoms, setSymptoms] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(symptomKeys.map((key) => [key, false])),
  );

  return (
    <div className="space-y-4">
      <form
        className="rounded-2xl bg-white p-4 shadow-sm"
        onSubmit={(e) => {
          e.preventDefault();
          setMessage("");

          const optimistic: CaseItem = {
            id: -Date.now(),
            animalId: Number(animalId),
            animalName: animals.find((a) => a.id === Number(animalId))?.name ?? "Unknown",
            species: animals.find((a) => a.id === Number(animalId))?.species ?? "cattle",
            symptomsText,
            predictedDisease: "Predicting...",
            confidence: 0,
            severity: "low",
            recommendation: "",
            status: "open",
            vetDiagnosis: null,
            createdAt: new Date().toISOString(),
          };

          setRecords((curr) => [optimistic, ...curr]);

          startTransition(async () => {
            const res = await fetch("/api/cases", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                animalId: Number(animalId),
                symptomsText,
                symptomFlags: symptoms,
                environmentalFactors: {
                  location,
                  temperatureC,
                  humidityPct,
                  season,
                  outbreakNearby,
                },
              }),
            });

            if (!res.ok) {
              setRecords((curr) => curr.filter((c) => c.id !== optimistic.id));
              setMessage("Case submission failed.");
              return;
            }

            const payload = (await res.json()) as { data: CaseItem };
            setRecords((curr) => [payload.data, ...curr.filter((c) => c.id !== optimistic.id)]);
            setSymptomsText("");
            setSymptoms(Object.fromEntries(symptomKeys.map((key) => [key, false])));
            setMessage("AI prediction generated and case recorded.");
          });
        }}
      >
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-lg font-semibold">Report New Case</h3>
          {pending ? <span className="text-xs text-slate-500">Saving...</span> : null}
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          <label className="text-sm">
            Animal
            <select
              required
              value={animalId}
              onChange={(e) => setAnimalId(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2"
            >
              {animals.map((animal) => (
                <option key={animal.id} value={animal.id}>
                  {animal.name} ({animal.tagId})
                </option>
              ))}
            </select>
          </label>
          <label className="text-sm">
            Location
            <input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2"
            />
          </label>
          <label className="text-sm">
            Temperature (°C)
            <input
              value={temperatureC}
              type="number"
              onChange={(e) => setTemperatureC(Number(e.target.value))}
              className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2"
            />
          </label>
          <label className="text-sm">
            Humidity (%)
            <input
              value={humidityPct}
              type="number"
              onChange={(e) => setHumidityPct(Number(e.target.value))}
              className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2"
            />
          </label>
          <label className="text-sm">
            Season
            <select
              value={season}
              onChange={(e) => setSeason(e.target.value as "summer" | "monsoon" | "winter" | "spring")}
              className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2"
            >
              <option value="summer">summer</option>
              <option value="monsoon">monsoon</option>
              <option value="winter">winter</option>
              <option value="spring">spring</option>
            </select>
          </label>
          <label className="mt-6 inline-flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={outbreakNearby}
              onChange={(e) => setOutbreakNearby(e.target.checked)}
            />
            Outbreak reported nearby
          </label>
        </div>

        <div className="mt-3">
          <p className="text-sm font-medium">Symptoms checklist</p>
          <div className="mt-2 grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
            {symptomKeys.map((key) => (
              <label key={key} className="inline-flex items-center gap-2 rounded-lg border border-slate-200 px-2 py-1 text-sm">
                <input
                  type="checkbox"
                  checked={Boolean(symptoms[key])}
                  onChange={(e) => setSymptoms((curr) => ({ ...curr, [key]: e.target.checked }))}
                />
                {key}
              </label>
            ))}
          </div>
        </div>

        <label className="mt-3 block text-sm">
          Additional notes
          <textarea
            value={symptomsText}
            onChange={(e) => setSymptomsText(e.target.value)}
            rows={3}
            className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2"
            placeholder="e.g. Fever for two days and visible skin nodules"
          />
        </label>

        <button className="mt-3 rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white">
          Predict Disease
        </button>
      </form>

      {message ? <p className="text-sm text-slate-600">{message}</p> : null}

      <section className="rounded-2xl bg-white p-4 shadow-sm">
        <h3 className="text-lg font-semibold">Case Timeline</h3>
        {records.length === 0 ? (
          <p className="mt-3 rounded-xl border border-dashed border-slate-300 p-4 text-sm text-slate-500">
            No cases yet. Submit a symptom report to receive AI prediction and action recommendations.
          </p>
        ) : (
          <div className="mt-3 space-y-3">
            {records.map((item) => (
              <article key={item.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-semibold">{item.animalName} • {item.predictedDisease}</p>
                  <span className="rounded-full bg-slate-100 px-2 py-1 text-xs">{item.confidence}%</span>
                </div>
                <p className="mt-1 text-slate-600">Severity: {item.severity} • Status: {item.status}</p>
                <p className="text-slate-500">{item.recommendation}</p>
                {item.vetDiagnosis ? <p className="mt-1 text-xs text-emerald-700">Vet: {item.vetDiagnosis}</p> : null}

                <div className="mt-2 flex flex-wrap gap-2">
                  {(role === "veterinarian" || role === "admin") && item.id > 0 ? (
                    <>
                      {(["open", "in_treatment", "resolved"] as const).map((status) => (
                        <button
                          key={status}
                          className="rounded-lg border border-slate-300 px-2 py-1 text-xs hover:bg-slate-100"
                          onClick={() => {
                            startTransition(async () => {
                              const res = await fetch(`/api/cases/${item.id}`, {
                                method: "PATCH",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ status }),
                              });
                              if (!res.ok) return;
                              setRecords((curr) => curr.map((c) => (c.id === item.id ? { ...c, status } : c)));
                            });
                          }}
                        >
                          Mark {status}
                        </button>
                      ))}
                    </>
                  ) : null}

                  {item.id > 0 ? (
                    <button
                      className="rounded-lg border border-rose-300 px-2 py-1 text-xs text-rose-700 hover:bg-rose-50"
                      onClick={() => {
                        const prev = records;
                        setRecords((curr) => curr.filter((c) => c.id !== item.id));
                        startTransition(async () => {
                          const res = await fetch(`/api/cases/${item.id}`, { method: "DELETE" });
                          if (!res.ok) setRecords(prev);
                        });
                      }}
                    >
                      Delete
                    </button>
                  ) : null}
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
