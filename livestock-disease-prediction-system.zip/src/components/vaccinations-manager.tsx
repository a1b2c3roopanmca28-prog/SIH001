"use client";

import { useState, useTransition } from "react";

type AnimalOption = { id: number; name: string; tagId: string };

type Vaccination = {
  id: number;
  animalId: number;
  animalName?: string;
  vaccineName: string;
  dueDate: string;
  status: "due" | "completed" | "missed";
  notes: string;
};

export function VaccinationsManager({
  initialData,
  animals,
  canManage,
}: {
  initialData: Vaccination[];
  animals: AnimalOption[];
  canManage: boolean;
}) {
  const [records, setRecords] = useState(initialData);
  const [pending, startTransition] = useTransition();
  const [message, setMessage] = useState("");

  const [animalId, setAnimalId] = useState(String(animals[0]?.id ?? ""));
  const [vaccineName, setVaccineName] = useState("FMD Booster");
  const [dueDate, setDueDate] = useState(new Date().toISOString().slice(0, 10));

  return (
    <div className="space-y-4">
      {canManage ? (
        <form
          className="rounded-2xl bg-white p-4 shadow-sm"
          onSubmit={(e) => {
            e.preventDefault();
            setMessage("");

            startTransition(async () => {
              const res = await fetch("/api/vaccinations", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ animalId: Number(animalId), vaccineName, dueDate, status: "due" }),
              });

              if (!res.ok) {
                setMessage("Failed to create vaccination record.");
                return;
              }

              const payload = (await res.json()) as { data: Vaccination };
              setRecords((curr) => [payload.data, ...curr]);
              setMessage("Vaccination reminder created.");
            });
          }}
        >
          <h3 className="text-lg font-semibold">Create Vaccination Reminder</h3>
          <div className="mt-2 grid gap-3 md:grid-cols-3">
            <label className="text-sm">
              Animal
              <select
                className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2"
                value={animalId}
                onChange={(e) => setAnimalId(e.target.value)}
              >
                {animals.map((animal) => (
                  <option key={animal.id} value={animal.id}>
                    {animal.name} ({animal.tagId})
                  </option>
                ))}
              </select>
            </label>
            <label className="text-sm">
              Vaccine
              <input
                className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2"
                value={vaccineName}
                onChange={(e) => setVaccineName(e.target.value)}
              />
            </label>
            <label className="text-sm">
              Due date
              <input
                type="date"
                className="mt-1 w-full rounded-xl border border-slate-300 px-3 py-2"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </label>
          </div>

          <button disabled={pending} className="mt-3 rounded-xl bg-slate-900 px-4 py-2 text-sm text-white">
            {pending ? "Saving..." : "Add Reminder"}
          </button>
        </form>
      ) : (
        <p className="rounded-xl border border-dashed border-slate-300 bg-white p-4 text-sm text-slate-600">
          Farmers can view reminders. Veterinarian/admin can manage reminders and completion status.
        </p>
      )}

      {message ? <p className="text-sm text-slate-600">{message}</p> : null}

      <section className="rounded-2xl bg-white p-4 shadow-sm">
        <h3 className="text-lg font-semibold">Vaccination Records</h3>
        {records.length === 0 ? (
          <p className="mt-3 rounded-xl border border-dashed border-slate-300 p-4 text-sm text-slate-500">No records found.</p>
        ) : (
          <div className="mt-3 space-y-3">
            {records.map((record) => (
              <article key={record.id} className="rounded-xl border border-slate-200 p-3 text-sm">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="font-medium">{record.vaccineName} • {record.animalName ?? `Animal #${record.animalId}`}</p>
                  <span className="rounded-full bg-slate-100 px-2 py-1 text-xs">{record.status}</span>
                </div>
                <p className="text-slate-600">Due: {new Date(record.dueDate).toLocaleDateString()}</p>
                <p className="text-xs text-slate-500">{record.notes}</p>

                {canManage ? (
                  <div className="mt-2 flex flex-wrap gap-2">
                    {(["due", "completed", "missed"] as const).map((status) => (
                      <button
                        key={status}
                        className="rounded-lg border border-slate-300 px-2 py-1 text-xs hover:bg-slate-100"
                        onClick={() => {
                          startTransition(async () => {
                            const res = await fetch(`/api/vaccinations/${record.id}`, {
                              method: "PATCH",
                              headers: { "Content-Type": "application/json" },
                              body: JSON.stringify({ status }),
                            });
                            if (!res.ok) return;
                            setRecords((curr) => curr.map((r) => (r.id === record.id ? { ...r, status } : r)));
                          });
                        }}
                      >
                        Mark {status}
                      </button>
                    ))}
                    <button
                      className="rounded-lg border border-rose-300 px-2 py-1 text-xs text-rose-700 hover:bg-rose-50"
                      onClick={() => {
                        const prev = records;
                        setRecords((curr) => curr.filter((r) => r.id !== record.id));
                        startTransition(async () => {
                          const res = await fetch(`/api/vaccinations/${record.id}`, { method: "DELETE" });
                          if (!res.ok) setRecords(prev);
                        });
                      }}
                    >
                      Delete
                    </button>
                  </div>
                ) : null}
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
